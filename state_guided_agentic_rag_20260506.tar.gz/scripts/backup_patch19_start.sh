#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch19_entity_expansion_start
cp -r src prompts scripts configs backups/patch19_entity_expansion_start/
echo "[done] backup created at backups/patch19_entity_expansion_start"
