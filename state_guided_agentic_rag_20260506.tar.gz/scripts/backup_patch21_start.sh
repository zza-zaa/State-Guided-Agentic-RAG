#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch21_evidence_gate_start
cp -r src prompts scripts configs backups/patch21_evidence_gate_start/
echo "[done] backup created at backups/patch21_evidence_gate_start"
