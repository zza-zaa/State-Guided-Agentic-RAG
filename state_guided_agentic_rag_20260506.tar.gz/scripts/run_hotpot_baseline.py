from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

import typer
from rich import print

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from csa_rag.embedding.bge_embedder import BGEEmbedder
from csa_rag.retrieval.retriever import DenseRetriever
from csa_rag.llm.vllm_llm import VLLMLLM
from csa_rag.rerank.bge_reranker import BGEReranker

app = typer.Typer()


def load_hotpot(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def canonicalize_answer(text: str) -> str:
    s = str(text).strip()

    # 去掉 code fence
    if s.startswith("```"):
        s = re.sub(r"^```(?:json)?\s*", "", s)
        s = re.sub(r"\s*```$", "", s).strip()

    # 常见前缀
    s = re.sub(r"^(?i)(answer:|the answer is)\s*", "", s).strip()

    # yes/no 统一
    low = s.lower().strip(" .")
    if low in {"yes", "true"}:
        return "yes"
    if low in {"no", "false"}:
        return "no"

    # 第一行优先
    s = s.splitlines()[0].strip()

    # 比较题句式：X is older than Y -> 只保留 X
    m = re.match(r"^(.+?)\s+is\s+(older|younger)\s+than\s+.+$", s, flags=re.I)
    if m:
        return m.group(1).strip()

    return s.strip()


@app.command()
def main(
    dataset_path: Path = typer.Option(..., exists=True),
    index_dir: Path = typer.Option(..., exists=True),
    output_path: Path = typer.Option(...),
    limit: int = typer.Option(20),
    offset: int = typer.Option(0),
    use_reranker: bool = typer.Option(False),
):
    data = load_hotpot(dataset_path)[offset: offset + limit]

    embedder = BGEEmbedder("/mnt/raid/peiyu/models/bge-m3")
    retriever = DenseRetriever(index_dir=index_dir, embedder=embedder)

    llm = VLLMLLM(
        model_name="/mnt/raid/zsb/llm_models/Qwen3-14B",
        max_model_len=4096,
        temperature=0.0,
        top_p=1.0,
        top_k=20,
        max_new_tokens=128,
        thinking=False,
    )

    reranker = None
    if use_reranker:
        reranker = BGEReranker("/mnt/raid/peiyu/models/bge-reranker-v2-m3", use_fp16=True)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    with output_path.open("w", encoding="utf-8") as f:
        for i, ex in enumerate(data, start=1):
            qid = ex.get("_id", ex.get("id", f"ex-{offset+i}"))
            question = ex["question"]
            gold = ex.get("answer", "")

            evs = retriever.search(question, top_k=12)
            if reranker is not None:
                evs = reranker.rerank(question, evs, top_k=5)
            else:
                evs = evs[:5]

            context = "\n\n".join(
                [f"[{k+1}] {e.text}" for k, e in enumerate(evs)]
            )

            prompt = (
                "You are answering a question using retrieved evidence.\n"
                "Return only a short answer. No explanation.\n"
                "If the answer is yes/no, return exactly yes or no.\n\n"
                f"Question: {question}\n\n"
                f"Evidence:\n{context}\n\n"
                "Short answer:"
            )

            raw_pred = llm.generate_text(prompt).strip()
            pred = canonicalize_answer(raw_pred)

            row = {
                "qid": qid,
                "question": question,
                "gold_answer": gold,
                "pred_answer": pred,
                "raw_pred_answer": raw_pred,
                "retrieved_evidence": [e.model_dump() for e in evs],
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            f.flush()

            print("=" * 80)
            print(f"[{i}/{len(data)}] {qid}")
            print(f"[gold] {gold}")
            print(f"[pred] {pred}")

    print(f"[done] wrote predictions to {output_path}")


if __name__ == "__main__":
    app()
