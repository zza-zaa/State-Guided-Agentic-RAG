#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

mkdir -p bundles
BUNDLE_DIR="bundles/csa_rag_bundle"
rm -rf "$BUNDLE_DIR"
mkdir -p "$BUNDLE_DIR"

cp -r configs "$BUNDLE_DIR/"
cp -r prompts "$BUNDLE_DIR/"
cp -r scripts "$BUNDLE_DIR/"
cp -r src "$BUNDLE_DIR/"
cp -r wheelhouse "$BUNDLE_DIR/" || true
cp -r models "$BUNDLE_DIR/" || true
cp environment.yml requirements.txt README.md "$BUNDLE_DIR/"

cat > "$BUNDLE_DIR/scripts/server_install_from_bundle.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install --no-index --find-links wheelhouse -r requirements.txt

echo "[done] server environment created at $ROOT_DIR/.venv"
EOF
chmod +x "$BUNDLE_DIR/scripts/server_install_from_bundle.sh"

tar -czf "bundles/csa_rag_bundle.tar.gz" -C bundles csa_rag_bundle

echo "[done] created bundles/csa_rag_bundle.tar.gz"
