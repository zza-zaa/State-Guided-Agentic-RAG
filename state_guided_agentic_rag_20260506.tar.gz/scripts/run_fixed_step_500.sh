#!/usr/bin/env bash
set -euo pipefail

STEP="$1"
DATASET_KEY="$2"

cd /mnt/raid/peiyu/csa
set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u
export PYTHONPATH=src

CONFIG="configs/fixed_steps/main_full_14b_fixedstep${STEP}.yaml"

if [ "$DATASET_KEY" = "hotpot" ]; then
  RUNNER="scripts/run_hotpot_eval.py"
  DATASET_PATH="/mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json"
  INDEX_DIR="data/indexes/hotpot"
elif [ "$DATASET_KEY" = "2wiki" ]; then
  RUNNER="scripts/run_2wiki_eval.py"
  DATASET_PATH="/mnt/raid/peiyu/dataset/2Wiki/dev.json"
  INDEX_DIR="data/indexes/2wiki"
elif [ "$DATASET_KEY" = "musique" ]; then
  RUNNER="scripts/run_musique_eval.py"
  DATASET_PATH="/mnt/raid/peiyu/dataset/musique/musique_ans_v1.0_dev.jsonl"
  INDEX_DIR="data/indexes/musique"
else
  echo "[error] unknown dataset: $DATASET_KEY"
  exit 1
fi

OUT_PREFIX="outputs/fixed_steps/${DATASET_KEY}_qwen3_14b_fixedstep${STEP}_500"
LOG="${OUT_PREFIX}.log"
TIME_LOG="${OUT_PREFIX}.time"
METRICS="${OUT_PREFIX}_metrics.json"

if [ -s "${OUT_PREFIX}.jsonl" ] && [ -s "$METRICS" ]; then
  echo "[skip] existing result found: $METRICS"
  cat "$METRICS"
  exit 0
fi

echo "[run] dataset=${DATASET_KEY}, fixed_step=${STEP}, config=${CONFIG}"

/usr/bin/time -f "wall_sec=%e\nuser_sec=%U\nsys_sec=%S\nmax_rss_kb=%M" \
  -o "$TIME_LOG" \
  python -u "$RUNNER" \
    --dataset-path "$DATASET_PATH" \
    --index-dir "$INDEX_DIR" \
    --models-config "$CONFIG" \
    --output-path "${OUT_PREFIX}.jsonl" \
    --limit 500 \
  > "$LOG" 2>&1

python scripts/eval_em_f1.py \
  --predictions "${OUT_PREFIX}.jsonl" \
  --output "$METRICS"

cat "$METRICS"
cat "$TIME_LOG"
