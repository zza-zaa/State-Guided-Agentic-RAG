from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from csa_rag.schema import Slot, KnowledgeState

slot = Slot(slot_id="s1", description="mother of Lothair II", slot_type="entity")
state = KnowledgeState(question="When did Lothair II's mother die?", slots=[slot])
print(state.model_dump_json(indent=2))
