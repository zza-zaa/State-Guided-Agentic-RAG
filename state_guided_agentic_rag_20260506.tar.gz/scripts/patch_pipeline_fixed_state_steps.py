from pathlib import Path
import re

p = Path("src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

pattern = re.compile(
r'''        agent_cfg = self\.cfg\.get\("agent", \{\}\)
        pipe_cfg = self\.cfg\.get\("pipeline", \{\}\)

        # Fixed-step experiment support:
        # - For normal runs, use agent\.max_steps as before\.
        # - For fixed-step sensitivity runs, pipeline\.fixed_steps / step_budget
        #   overrides agent\.max_steps\.
        max_steps = int\(
            pipe_cfg\.get\(
                "fixed_steps",
                pipe_cfg\.get\(
                    "fixed_step_limit",
                    pipe_cfg\.get\(
                        "fixed_max_steps",
                        pipe_cfg\.get\(
                            "step_budget",
                            pipe_cfg\.get\("max_steps", agent_cfg\.get\("max_steps", 5\)\),
                        \),
                    \),
                \),
            \)
        \)

        force_fixed_steps = bool\(
            pipe_cfg\.get\("force_fixed_steps", False\)
            or pipe_cfg\.get\("disable_early_stop", False\)
        \)
        enable_early_stop = bool\(pipe_cfg\.get\("enable_early_stop", True\)\)

        retry_used = False

        for _ in range\(max_steps\):
            evidence = self\._retrieve_step\(state, typed_spec=typed_spec\)
            if evidence:
                all_evidence\.extend\(evidence\)
                state = self\.tracker\.update\(state, evidence\)
                state = self\.state_critic\.review\(state, all_evidence\)

            if self\.enable_typed_retry and not retry_used:
                retry_evidence = self\._typed_retry_step\(state, typed_spec=typed_spec\)
                if retry_evidence:
                    all_evidence\.extend\(retry_evidence\)
                    state = self\.tracker\.update\(state, retry_evidence\)
                    state = self\.state_critic\.review\(state, all_evidence\)
                    retry_used = True

            # In fixed-step experiments, do not stop early by confidence\.
            if \(not force_fixed_steps\) and enable_early_stop:
                if self\.calibrator\.should_stop\(state, max_steps=max_steps\):
                    break
''',
re.S
)

new = '''        agent_cfg = self.cfg.get("agent", {})
        pipe_cfg = self.cfg.get("pipeline", {})

        # Fixed-state-step experiment support:
        # - Normal runs keep the original behavior.
        # - Fixed-step runs treat the configured value as the target number of
        #   state updates, i.e., the final RunResult.steps / state.step.
        max_steps = int(
            pipe_cfg.get(
                "fixed_steps",
                pipe_cfg.get(
                    "fixed_step_limit",
                    pipe_cfg.get(
                        "fixed_max_steps",
                        pipe_cfg.get(
                            "step_budget",
                            pipe_cfg.get("max_steps", agent_cfg.get("max_steps", 5)),
                        ),
                    ),
                ),
            )
        )

        force_fixed_steps = bool(
            pipe_cfg.get("force_fixed_steps", False)
            or pipe_cfg.get("disable_early_stop", False)
        )
        enable_early_stop = bool(pipe_cfg.get("enable_early_stop", True))

        retry_used = False

        if force_fixed_steps:
            # Here max_steps is interpreted as the target state.step budget.
            # A retrieve update and a typed-retry update may both occur in one
            # outer loop, so we explicitly stop once state.step reaches target.
            target_state_steps = max_steps
            guard = 0
            max_guard = max(3, target_state_steps * 4 + 4)

            while state.step < target_state_steps and guard < max_guard:
                guard += 1
                before_step = state.step

                evidence = self._retrieve_step(state, typed_spec=typed_spec)
                if evidence:
                    all_evidence.extend(evidence)
                    state = self.tracker.update(state, evidence)
                    state = self.state_critic.review(state, all_evidence)

                if state.step >= target_state_steps:
                    break

                if self.enable_typed_retry and not retry_used:
                    retry_evidence = self._typed_retry_step(state, typed_spec=typed_spec)
                    if retry_evidence:
                        all_evidence.extend(retry_evidence)
                        state = self.tracker.update(state, retry_evidence)
                        state = self.state_critic.review(state, all_evidence)
                        retry_used = True

                if state.step >= target_state_steps:
                    break

                # Avoid infinite loops if neither retrieval nor retry updates state.
                if state.step == before_step:
                    break

        else:
            for _ in range(max_steps):
                evidence = self._retrieve_step(state, typed_spec=typed_spec)
                if evidence:
                    all_evidence.extend(evidence)
                    state = self.tracker.update(state, evidence)
                    state = self.state_critic.review(state, all_evidence)

                if self.enable_typed_retry and not retry_used:
                    retry_evidence = self._typed_retry_step(state, typed_spec=typed_spec)
                    if retry_evidence:
                        all_evidence.extend(retry_evidence)
                        state = self.tracker.update(state, retry_evidence)
                        state = self.state_critic.review(state, all_evidence)
                        retry_used = True

                if enable_early_stop:
                    if self.calibrator.should_stop(state, max_steps=max_steps):
                        break
'''

m = pattern.search(text)
if not m:
    raise SystemExit("[error] fixed-step loop block not found. Please inspect pipeline.py around run().")

text = text[:m.start()] + new + text[m.end():]
p.write_text(text, encoding="utf-8")

print("[ok] patched pipeline.py: fixed_steps now controls state.step budget")
