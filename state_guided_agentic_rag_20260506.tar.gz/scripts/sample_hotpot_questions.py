from __future__ import annotations

import json
from pathlib import Path
import typer

app = typer.Typer()

def iter_records(path: Path):
    if path.suffix == ".jsonl":
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    yield json.loads(line)
    elif path.suffix == ".json":
        with path.open("r", encoding="utf-8") as f:
            obj = json.load(f)
        if isinstance(obj, list):
            for x in obj:
                yield x

@app.command()
def main(input_dir: Path = typer.Option(..., exists=True)):
    files = sorted([p for p in input_dir.rglob("*") if p.is_file() and p.suffix in {".json", ".jsonl"}])
    printed = 0
    for fp in files:
        for rec in iter_records(fp):
            if isinstance(rec, dict) and "question" in rec:
                print("=" * 80)
                print("file:", fp)
                print("id:", rec.get("_id") or rec.get("id"))
                print("question:", rec["question"])
                print("answer:", rec.get("answer"))
                printed += 1
                if printed >= 5:
                    return

if __name__ == "__main__":
    app()
