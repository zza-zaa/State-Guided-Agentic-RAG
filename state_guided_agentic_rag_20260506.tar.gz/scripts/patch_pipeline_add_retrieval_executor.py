from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

# 1) import
imp = "from csa_rag.retrieval.retrieval_executor import RetrievalExecutor"
if imp not in text:
    anchor = "from csa_rag.retrieval.slot_router import SlotRouter"
    if anchor not in text:
        raise SystemExit("Import anchor for SlotRouter not found")
    text = text.replace(anchor, anchor + "\n" + imp)

# 2) init
init_line = "self.retrieval_executor = RetrievalExecutor(self.retriever, self.reranker)"
if init_line not in text:
    anchor = "self.retriever = DenseRetriever(index_dir=index_dir, embedder=self.embedder)"
    if anchor not in text:
        raise SystemExit("Retriever init anchor not found")
    text = text.replace(anchor, anchor + "\n        " + init_line)

# 3) replace routed retrieval block
old = """        routed_query = plan.query if getattr(plan, "query", None) else query
        dense = self.retriever.search(routed_query, top_k=top_k_dense)
        reranked = self.reranker.rerank(query=routed_query, evidence=dense, top_k=top_k_rerank)
        first_hop = reranked[:step_cap]
"""

new = """        routed_query = plan.query if getattr(plan, "query", None) else query
        plan.query = routed_query
        route_title_hits, reranked = self.retrieval_executor.execute(plan)
        route_title_hits = route_title_hits[:step_cap]
        first_hop = reranked[:step_cap]
"""

if old not in text:
    raise SystemExit("Could not find routed retrieval block to replace")
text = text.replace(old, new, 1)

# 4) change merge order for dependent slots
old_dep = """        if slot is not None and (getattr(slot, "depends_on", []) or []) and getattr(slot, "target_role", "other") in {"dependent", "answer_target"}:
            return self._merge_evidence(
                value_title_hits,
                second_hop,
                first_hop,
                title_hits,
                limit=self.retrieval_merge_limit,
            )
"""

new_dep = """        if slot is not None and (getattr(slot, "depends_on", []) or []) and getattr(slot, "target_role", "other") in {"dependent", "answer_target"}:
            return self._merge_evidence(
                route_title_hits,
                value_title_hits,
                second_hop,
                first_hop,
                title_hits,
                limit=self.retrieval_merge_limit,
            )
"""

if old_dep in text:
    text = text.replace(old_dep, new_dep, 1)
else:
    print("[warn] dependent merge block not matched exactly; skipping dependent merge replacement")

# 5) change default merge order to include routed title hits too
old_def = """        return self._merge_evidence(
            first_hop,
            value_title_hits,
            second_hop,
            title_hits,
            limit=self.retrieval_merge_limit,
        )
"""

new_def = """        return self._merge_evidence(
            route_title_hits,
            first_hop,
            value_title_hits,
            second_hop,
            title_hits,
            limit=self.retrieval_merge_limit,
        )
"""

if old_def in text:
    text = text.replace(old_def, new_def, 1)
else:
    print("[warn] default merge block not matched exactly; skipping default merge replacement")

p.write_text(text, encoding="utf-8")
print("[ok] pipeline patched with RetrievalExecutor")
