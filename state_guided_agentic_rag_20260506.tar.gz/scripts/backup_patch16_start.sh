#!/usr/bin/env bash
set -euo pipefail
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch16_state_critic_start
cp -r src prompts scripts configs backups/patch16_state_critic_start/
echo "[done] backup created at backups/patch16_state_critic_start"
