from pathlib import Path
import json

steps = [1, 2, 3, 4, 5, 7, 9]
datasets = ["hotpot", "2wiki", "musique"]
limit = 100
offset = 0

def read_time(path: Path):
    if not path.exists():
        return {}
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            try:
                out[k] = float(v)
            except Exception:
                out[k] = v
    return out

records = []
lines = []
lines.append("| Fixed State-Step Budget | Dataset | EM | F1 | Observed Avg State Steps | Error Count | Wall Sec | User Sec | Max RSS KB |")
lines.append("|---:|---|---:|---:|---:|---:|---:|---:|---:|")

for s in steps:
    for ds in datasets:
        prefix = Path(f"outputs/fixed_steps/{ds}_qwen3_14b_fixedstep{s}_L{limit}_O{offset}")
        mp = Path(str(prefix) + "_metrics.json")
        tp = Path(str(prefix) + ".time")

        if not mp.exists():
            lines.append(f"| {s} | {ds} | - | - | - | - | - | - | - |")
            continue

        m = json.loads(mp.read_text(encoding="utf-8"))
        t = read_time(tp)

        rec = {
            "fixed_state_step_budget": s,
            "dataset": ds,
            "EM": m.get("EM"),
            "F1": m.get("F1"),
            "observed_avg_state_steps": m.get("avg_steps"),
            "error_count": m.get("error_count"),
            "wall_sec": t.get("wall_sec"),
            "user_sec": t.get("user_sec"),
            "max_rss_kb": t.get("max_rss_kb"),
        }
        records.append(rec)

        lines.append(
            f"| {s} | {ds} | "
            f"{rec['EM']} | {rec['F1']} | {rec['observed_avg_state_steps']} | "
            f"{rec['error_count']} | {rec['wall_sec']} | {rec['user_sec']} | {rec['max_rss_kb']} |"
        )

lines.append("")
lines.append("## Average over three datasets")
lines.append("")
lines.append("| Fixed State-Step Budget | Avg EM | Avg F1 | Avg Observed State Steps | Total Errors | Avg Wall Sec |")
lines.append("|---:|---:|---:|---:|---:|---:|")

for s in steps:
    rs = [r for r in records if r["fixed_state_step_budget"] == s]
    if not rs:
        lines.append(f"| {s} | - | - | - | - | - |")
        continue

    def avg(key):
        vals = [r[key] for r in rs if isinstance(r.get(key), (int, float))]
        return round(sum(vals) / len(vals), 4) if vals else None

    total_err = sum(r.get("error_count", 0) or 0 for r in rs)

    lines.append(
        f"| {s} | {avg('EM')} | {avg('F1')} | {avg('observed_avg_state_steps')} | "
        f"{total_err} | {avg('wall_sec')} |"
    )

out_md = Path("outputs/fixed_steps/fixed_step_summary_L100_O0.md")
out_json = Path("outputs/fixed_steps/fixed_step_summary_L100_O0.json")
out_md.parent.mkdir(parents=True, exist_ok=True)

out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
out_json.write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print(f"[done] wrote {out_md}")
print(f"[done] wrote {out_json}")
print()
print(out_md.read_text(encoding="utf-8"))
