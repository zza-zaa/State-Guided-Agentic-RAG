#!/usr/bin/env bash
set -euo pipefail

DATA_HOTPOT=/mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json
DATA_2WIKI=/mnt/raid/peiyu/dataset/2Wiki/dev.json
DATA_MUSIQUE=/mnt/raid/peiyu/dataset/musique/musique_ans_v1.0_dev.jsonl

INDEX_HOTPOT=data/indexes/hotpot
INDEX_2WIKI=data/indexes/2wiki
INDEX_MUSIQUE=data/indexes/musique

CFG=configs/models.yaml

mkdir -p outputs/logs

echo "=== syntax check ==="
python -m py_compile \
  src/csa_rag/utils/json_utils.py \
  src/csa_rag/llm/vllm_llm.py \
  src/csa_rag/schema.py \
  src/csa_rag/agent/calibration.py \
  scripts/run_2wiki_eval.py \
  scripts/run_musique_eval.py

echo "=== Hotpot 100 ==="
python -u scripts/run_hotpot_eval.py \
  --dataset-path "$DATA_HOTPOT" \
  --index-dir "$INDEX_HOTPOT" \
  --models-config "$CFG" \
  --output-path outputs/hotpot_dev100_emnlp_next.jsonl \
  --limit 100 \
  > outputs/logs/hotpot_dev100_emnlp_next.log 2>&1

python scripts/eval_em_f1.py \
  --predictions outputs/hotpot_dev100_emnlp_next.jsonl \
  --output outputs/hotpot_dev100_emnlp_next_metrics.json

echo "=== 2Wiki 100 ==="
python -u scripts/run_2wiki_eval.py \
  --dataset-path "$DATA_2WIKI" \
  --index-dir "$INDEX_2WIKI" \
  --models-config "$CFG" \
  --output-path outputs/2wiki_dev100_emnlp_next.jsonl \
  --limit 100 \
  > outputs/logs/2wiki_dev100_emnlp_next.log 2>&1

python scripts/eval_em_f1.py \
  --predictions outputs/2wiki_dev100_emnlp_next.jsonl \
  --output outputs/2wiki_dev100_emnlp_next_metrics.json

echo "=== MuSiQue 100 ==="
python -u scripts/run_musique_eval.py \
  --dataset-path "$DATA_MUSIQUE" \
  --index-dir "$INDEX_MUSIQUE" \
  --models-config "$CFG" \
  --output-path outputs/musique_dev100_emnlp_next.jsonl \
  --limit 100 \
  > outputs/logs/musique_dev100_emnlp_next.log 2>&1

python scripts/eval_em_f1.py \
  --predictions outputs/musique_dev100_emnlp_next.jsonl \
  --output outputs/musique_dev100_emnlp_next_metrics.json

echo "=== MuSiQue error analysis ==="
python scripts/extract_errors.py \
  --predictions outputs/musique_dev100_emnlp_next.jsonl \
  --output outputs/musique_dev100_emnlp_next_errors.jsonl

python scripts/classify_errors.py \
  --errors outputs/musique_dev100_emnlp_next_errors.jsonl \
  --output outputs/musique_dev100_emnlp_next_errors_classified.jsonl

echo "=== result summary ==="
cat outputs/hotpot_dev100_emnlp_next_metrics.json
cat outputs/2wiki_dev100_emnlp_next_metrics.json
cat outputs/musique_dev100_emnlp_next_metrics.json

echo "=== MuSiQue error counts ==="
grep '"error_type": "answer_not_canonical"' outputs/musique_dev100_emnlp_next_errors_classified.jsonl | wc -l
grep '"error_type": "second_hop_missing"' outputs/musique_dev100_emnlp_next_errors_classified.jsonl | wc -l
grep '"error_type": "answer_failure"' outputs/musique_dev100_emnlp_next_errors_classified.jsonl | wc -l
grep '"error_type": "conflict_unresolved"' outputs/musique_dev100_emnlp_next_errors_classified.jsonl | wc -l
