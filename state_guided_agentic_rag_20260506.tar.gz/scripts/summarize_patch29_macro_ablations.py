from pathlib import Path
import json

ablations = [
    "patch29_stage1_base_14b",
    "patch29_stage2_typed_14b",
    "patch29_stage3_multihop_14b",
    "patch29_stage4_full_14b",
]
datasets = ["hotpot", "2wiki", "musique"]

lines = []
lines.append("| Stage | Dataset | EM | F1 | Avg Steps | Error Count |")
lines.append("|---|---|---:|---:|---:|---:|")

for ab in ablations:
    for ds in datasets:
        p = Path(f"outputs/{ds}_{ab}_500_metrics.json")
        if not p.exists():
            lines.append(f"| {ab} | {ds} | - | - | - | - |")
            continue
        x = json.loads(p.read_text(encoding="utf-8"))
        lines.append(
            f"| {ab} | {ds} | {x.get('EM','-')} | {x.get('F1','-')} | {x.get('avg_steps','-')} | {x.get('error_count','-')} |"
        )

out = Path("outputs/patch29_macro_ablation_summary_500.md")
out.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"[done] wrote {out}")
