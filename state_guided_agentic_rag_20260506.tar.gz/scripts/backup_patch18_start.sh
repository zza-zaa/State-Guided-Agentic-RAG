#!/usr/bin/env bash
set -euo pipefail
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch18_semantic_verifier_start
cp -r src prompts scripts configs backups/patch18_semantic_verifier_start/
echo "[done] backup created at backups/patch18_semantic_verifier_start"
