#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa

cp backups/patch19_entity_expansion_start/src/csa_rag/agent/pipeline.py src/csa_rag/agent/pipeline.py
rm -f src/csa_rag/retrieval/entity_expansion.py

python -m py_compile \
  src/csa_rag/agent/pipeline.py \
  scripts/run_hotpot_eval.py \
  scripts/run_2wiki_eval.py \
  scripts/run_musique_eval.py

echo "[done] rolled back patch19 to patch16 backbone"
