#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch23_typed_parser_start
cp -r src prompts scripts configs backups/patch23_typed_parser_start/
echo "[done] backup created at backups/patch23_typed_parser_start"
