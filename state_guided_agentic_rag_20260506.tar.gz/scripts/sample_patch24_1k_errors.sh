#!/usr/bin/env bash
set -e

cd /mnt/raid/peiyu/csa
set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u

for name in hotpot 2wiki musique; do
  echo "==================== ${name} ===================="

  python scripts/extract_errors.py \
    --predictions "outputs/${name}_dev1000_patch24_typed_soft.jsonl" \
    --output "outputs/${name}_dev1000_patch24_typed_soft_errors.jsonl"

  python scripts/classify_errors.py \
    --errors "outputs/${name}_dev1000_patch24_typed_soft_errors.jsonl" \
    --output "outputs/${name}_dev1000_patch24_typed_soft_errors_classified.jsonl"

  python scripts/sample_errors_by_type.py \
    --predictions "outputs/${name}_dev1000_patch24_typed_soft.jsonl" \
    --classified-errors "outputs/${name}_dev1000_patch24_typed_soft_errors_classified.jsonl" \
    --per-type 5

  echo "----- error counts -----"
  grep '"error_type": "answer_not_canonical"' "outputs/${name}_dev1000_patch24_typed_soft_errors_classified.jsonl" | wc -l || true
  grep '"error_type": "second_hop_missing"' "outputs/${name}_dev1000_patch24_typed_soft_errors_classified.jsonl" | wc -l || true
  grep '"error_type": "conflict_unresolved"' "outputs/${name}_dev1000_patch24_typed_soft_errors_classified.jsonl" | wc -l || true
  grep '"error_type": "answer_failure"' "outputs/${name}_dev1000_patch24_typed_soft_errors_classified.jsonl" | wc -l || true
done
