from pathlib import Path
import re

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

# Ensure pipe_cfg is defined before any pipe_cfg.get(...) use
init_anchor = 'self.answer_template = Template(Path("prompts/answer.txt").read_text(encoding="utf-8"))'
cfg_line = '        pipe_cfg = self.cfg.get("pipeline", {})\n'

if cfg_line not in text:
    text = text.replace(init_anchor, init_anchor + "\n\n" + cfg_line, 1)

# Remove later duplicated pipe_cfg assignment if present
dup_pattern = r'\n\s*pipe_cfg = self\.cfg\.get\("pipeline", \{\}\)\n'
matches = list(re.finditer(dup_pattern, text))
if len(matches) > 1:
    # keep first, remove later ones
    first_end = matches[0].end()
    new_text = text[:first_end]
    cursor = first_end
    for m in matches[1:]:
        new_text += text[cursor:m.start()]
        cursor = m.end()
    new_text += text[cursor:]
    text = new_text

p.write_text(text, encoding="utf-8")
print("[done] fixed pipe_cfg initialization order")
