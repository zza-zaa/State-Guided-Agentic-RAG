from __future__ import annotations

import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from csa_rag.llm.openai_compat_llm import OpenAICompatLLM

llm = OpenAICompatLLM(
    base_url="http://127.0.0.1:8000/v1",
    api_key="EMPTY",
    model_name="/mnt/raid/zsb/llm_models/Qwen3-14B",
    temperature=0.0,
    top_p=1.0,
    top_k=20,
    max_new_tokens=64,
    thinking=False,
)
print(llm.generate_text("Reply with exactly: server-ok"))
