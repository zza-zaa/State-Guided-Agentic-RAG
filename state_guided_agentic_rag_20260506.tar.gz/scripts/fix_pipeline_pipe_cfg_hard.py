from pathlib import Path
import re

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

target = '        self.cfg = load_yaml(models_config)\n'
insert = '        self.cfg = load_yaml(models_config)\n        pipe_cfg = self.cfg.get("pipeline", {})\n'

if target not in text:
    raise SystemExit("Could not find self.cfg = load_yaml(models_config) in pipeline.py")

# first remove every existing pipe_cfg assignment
text = re.sub(r'^\s*pipe_cfg = self\.cfg\.get\("pipeline", \{\}\)\s*$\n?', '', text, flags=re.M)

# then insert exactly once, immediately after self.cfg = load_yaml(...)
text = text.replace(target, insert, 1)

p.write_text(text, encoding="utf-8")
print("[done] hard-fixed pipe_cfg placement")
