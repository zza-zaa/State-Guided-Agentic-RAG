from __future__ import annotations

import json
import random
from collections import defaultdict
from pathlib import Path
import typer

app = typer.Typer()

@app.command()
def main(
    predictions: Path = typer.Option(..., exists=True),
    classified_errors: Path = typer.Option(..., exists=True),
    per_type: int = typer.Option(5),
    seed: int = typer.Option(42),
):
    pred_map = {}
    with predictions.open("r", encoding="utf-8") as f:
        for line in f:
            x = json.loads(line)
            pred_map[x.get("qid", "")] = x

    bucket = defaultdict(list)
    with classified_errors.open("r", encoding="utf-8") as f:
        for line in f:
            x = json.loads(line)
            bucket[x.get("error_type", "unknown")].append(x.get("qid", ""))

    random.seed(seed)

    for err_type, qids in bucket.items():
        print("=" * 140)
        print("ERROR TYPE:", err_type, "count=", len(qids))
        picks = random.sample(qids, min(per_type, len(qids)))
        for qid in picks:
            row = pred_map.get(qid, {})
            print("-" * 140)
            print("qid:", qid)
            print("question:", row.get("question"))
            print("gold:", row.get("gold_answer"))
            print("pred:", row.get("pred_answer"))
            print("raw_pred:", row.get("raw_pred_answer"))
            print("steps:", row.get("steps"))
            print("state:", json.dumps(row.get("state", {}), ensure_ascii=False, indent=2))
            ev = row.get("retrieved_evidence", [])
            print("retrieved_evidence_top3:")
            for e in ev[:3]:
                print(json.dumps(e, ensure_ascii=False))
            print("rationale:", row.get("rationale"))

if __name__ == "__main__":
    app()
