from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

# import
if "from csa_rag.state.state_critic import StateCritic" not in text:
    anchor = "from csa_rag.state.tracker import KnowledgeStateTracker"
    if anchor not in text:
        raise SystemExit("Import anchor not found")
    text = text.replace(anchor, anchor + "\nfrom csa_rag.state.state_critic import StateCritic")

# init
if "self.state_critic = StateCritic()" not in text:
    anchor = "self.tracker = KnowledgeStateTracker(self.llm)"
    if anchor not in text:
        raise SystemExit("Init anchor not found")
    text = text.replace(anchor, anchor + "\n        self.state_critic = StateCritic()")

# call after tracker/support_path
old = """                state = self.tracker.update(state, evidence)
                state = posthoc_validate_state(state, all_evidence)
"""
new = """                state = self.tracker.update(state, evidence)
                state = posthoc_validate_state(state, all_evidence)
                state = self.state_critic.review(state, all_evidence)
"""
if old not in text:
    raise SystemExit("State update block not found")
text = text.replace(old, new, 1)

p.write_text(text, encoding="utf-8")
print("[ok] pipeline patched with StateCritic")
