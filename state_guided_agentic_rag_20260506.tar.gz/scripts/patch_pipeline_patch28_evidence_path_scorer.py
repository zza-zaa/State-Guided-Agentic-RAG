from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old_import = "from csa_rag.retrieval.typed_second_hop import TypedSecondHopQueryBuilder"
new_import = "from csa_rag.retrieval.typed_second_hop import TypedSecondHopQueryBuilder\nfrom csa_rag.retrieval.evidence_path_scorer import EvidencePathScorer"
if "EvidencePathScorer" not in text:
    text = text.replace(old_import, new_import)

old_init = "self.typed_second_hop = TypedSecondHopQueryBuilder()"
new_init = "self.typed_second_hop = TypedSecondHopQueryBuilder()\n        self.evidence_path_scorer = EvidencePathScorer()"
if "self.evidence_path_scorer = EvidencePathScorer()" not in text:
    text = text.replace(old_init, new_init)

old_block = """        return self._merge_evidence(first_hop, value_title_hits, second_hop, title_hits, limit=self.retrieval_merge_limit)
"""
new_block = """        merged = self._merge_evidence(first_hop, value_title_hits, second_hop, title_hits, limit=self.retrieval_merge_limit)
        return self.evidence_path_scorer.select(
            merged,
            state=state,
            slot=slot,
            typed_spec=typed_spec,
            limit=self.retrieval_merge_limit,
        )
"""
if old_block not in text:
    raise SystemExit("Could not find merge-evidence return block in pipeline.py")

text = text.replace(old_block, new_block)
p.write_text(text, encoding="utf-8")
print("[done] patched pipeline with evidence path scorer")
