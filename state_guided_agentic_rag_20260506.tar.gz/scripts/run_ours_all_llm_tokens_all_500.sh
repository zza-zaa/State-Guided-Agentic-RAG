#!/usr/bin/env bash
set -euo pipefail

cd /mnt/raid/peiyu/csa
set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u
export PYTHONPATH=src

MODEL_CONFIG="configs/main_ablations/main_full_14b.yaml"
TOKENIZER_PATH="/mnt/raid/zsb/llm_models/Qwen3-14B"
LIMIT=500
OFFSET=0

mkdir -p outputs/llm_token_profile outputs/logs

run_one () {
  local DS="$1"
  local DATASET_PATH="$2"
  local INDEX_DIR="$3"

  local SUMMARY="outputs/llm_token_profile/${DS}_ours_14b_500_all_llm_tokens_summary.json"
  local DETAILS="outputs/llm_token_profile/${DS}_ours_14b_500_all_llm_tokens_details.jsonl"
  local LOG="outputs/logs/${DS}_ours_14b_500_all_llm_tokens.log"

  echo
  echo "==================== ${DS} all-LLM-token profiling ===================="

  python scripts/profile_ours_all_llm_tokens_500.py \
    --dataset-name "$DS" \
    --dataset-path "$DATASET_PATH" \
    --index-dir "$INDEX_DIR" \
    --models-config "$MODEL_CONFIG" \
    --tokenizer-path "$TOKENIZER_PATH" \
    --limit "$LIMIT" \
    --offset "$OFFSET" \
    --output-summary "$SUMMARY" \
    --output-details "$DETAILS" \
    > "$LOG" 2>&1

  cat "$SUMMARY"
}

run_one "hotpot" \
  "/mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json" \
  "data/indexes/hotpot"

run_one "2wiki" \
  "/mnt/raid/peiyu/dataset/2Wiki/dev.json" \
  "data/indexes/2wiki"

run_one "musique" \
  "/mnt/raid/peiyu/dataset/musique/musique_ans_v1.0_dev.jsonl" \
  "data/indexes/musique"

echo
echo "==================== Build all-LLM-token summary table ===================="

python - <<'PY'
from pathlib import Path
import json

items = [
    ("HotpotQA", "outputs/llm_token_profile/hotpot_ours_14b_500_all_llm_tokens_summary.json"),
    ("2Wiki", "outputs/llm_token_profile/2wiki_ours_14b_500_all_llm_tokens_summary.json"),
    ("MuSiQue", "outputs/llm_token_profile/musique_ours_14b_500_all_llm_tokens_summary.json"),
]

def fmt(v, nd=2):
    if v is None:
        return "-"
    if isinstance(v, (int, float)):
        return f"{v:.{nd}f}"
    return str(v)

rows = []
for ds, p in items:
    x = json.loads(Path(p).read_text(encoding="utf-8"))
    rows.append((ds, x))

lines = []
lines.append("| Dataset | Success | Fail | Avg LLM Calls | Avg Prompt Tokens | Avg Generation Tokens | Avg Total Tokens | Avg Time/Q excl. init | Avg Steps |")
lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|")

for ds, x in rows:
    lines.append(
        f"| {ds} | "
        f"{x.get('success_count')} | {x.get('fail_count')} | "
        f"{fmt(x.get('avg_llm_call_count_success_only'))} | "
        f"{fmt(x.get('avg_prompt_tokens_all_llm_calls'))} | "
        f"{fmt(x.get('avg_generation_tokens_all_llm_calls'))} | "
        f"{fmt(x.get('avg_total_tokens_all_llm_calls'))} | "
        f"{fmt(x.get('avg_time_sec_per_question_success_only_excl_init'))} | "
        f"{fmt(x.get('avg_steps_success_only'))} |"
    )

def avg(vals):
    vals = [v for v in vals if isinstance(v, (int, float))]
    return sum(vals) / len(vals) if vals else None

avg_row = {
    "success_count": sum(x.get("success_count", 0) for _, x in rows),
    "fail_count": sum(x.get("fail_count", 0) for _, x in rows),
    "avg_llm_call_count_success_only": avg([x.get("avg_llm_call_count_success_only") for _, x in rows]),
    "avg_prompt_tokens_all_llm_calls": avg([x.get("avg_prompt_tokens_all_llm_calls") for _, x in rows]),
    "avg_generation_tokens_all_llm_calls": avg([x.get("avg_generation_tokens_all_llm_calls") for _, x in rows]),
    "avg_total_tokens_all_llm_calls": avg([x.get("avg_total_tokens_all_llm_calls") for _, x in rows]),
    "avg_time_sec_per_question_success_only_excl_init": avg([x.get("avg_time_sec_per_question_success_only_excl_init") for _, x in rows]),
    "avg_steps_success_only": avg([x.get("avg_steps_success_only") for _, x in rows]),
}

lines.append(
    f"| **Average** | "
    f"{avg_row['success_count']} | {avg_row['fail_count']} | "
    f"{fmt(avg_row['avg_llm_call_count_success_only'])} | "
    f"{fmt(avg_row['avg_prompt_tokens_all_llm_calls'])} | "
    f"{fmt(avg_row['avg_generation_tokens_all_llm_calls'])} | "
    f"{fmt(avg_row['avg_total_tokens_all_llm_calls'])} | "
    f"{fmt(avg_row['avg_time_sec_per_question_success_only_excl_init'])} | "
    f"{fmt(avg_row['avg_steps_success_only'])} |"
)

note = """
Token note: Token counts are tokenizer-estimated with the Qwen3 tokenizer over all LLM calls.
For each question, every prompt input and model-generated output across the full inference process
is tokenized and summed. The table reports the average per successfully answered question.
""".strip()

lines.append("")
lines.append(note)

out = Path("outputs/llm_token_profile/ours_14b_500_all_llm_token_summary.md")
out.write_text("\n".join(lines) + "\n", encoding="utf-8")

print(out.read_text(encoding="utf-8"))
print(f"[done] wrote {out}")
PY
