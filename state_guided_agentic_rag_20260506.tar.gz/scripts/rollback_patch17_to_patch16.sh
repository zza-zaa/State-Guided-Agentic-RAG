#!/usr/bin/env bash
set -euo pipefail

cd /mnt/raid/peiyu/csa

cp backups/patch17_dependency_executor_start/src/csa_rag/agent/pipeline.py src/csa_rag/agent/pipeline.py
rm -f src/csa_rag/retrieval/retrieval_executor.py

python -m py_compile \
  src/csa_rag/agent/pipeline.py \
  scripts/run_hotpot_eval.py \
  scripts/run_2wiki_eval.py \
  scripts/run_musique_eval.py

echo "[done] rolled back patch17 to patch16 backbone"
