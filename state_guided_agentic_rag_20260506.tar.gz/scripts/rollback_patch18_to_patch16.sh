#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa

cp backups/patch18_semantic_verifier_start/src/csa_rag/agent/pipeline.py src/csa_rag/agent/pipeline.py
rm -f src/csa_rag/state/semantic_slot_verifier.py

python -m py_compile \
  src/csa_rag/agent/pipeline.py \
  scripts/run_hotpot_eval.py \
  scripts/run_2wiki_eval.py \
  scripts/run_musique_eval.py

echo "[done] rolled back patch18 to patch16 backbone"
