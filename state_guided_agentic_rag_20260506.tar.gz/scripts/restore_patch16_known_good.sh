#!/usr/bin/env bash
set -e

cd /mnt/raid/peiyu/csa

# choose the cleanest pre-patch17 backup if available
if [ -d backups/patch17_lite_start ]; then
  BASE=backups/patch17_lite_start
elif [ -d backups/patch17_dependency_executor_start ]; then
  BASE=backups/patch17_dependency_executor_start
else
  echo "[error] no patch16-era backup found"
  exit 1
fi

echo "[info] restoring from $BASE"

mkdir -p src/csa_rag/agent \
         src/csa_rag/state \
         src/csa_rag/retrieval \
         src/csa_rag/utils \
         prompts \
         scripts

cp "$BASE/src/csa_rag/agent/pipeline.py" src/csa_rag/agent/pipeline.py
cp "$BASE/src/csa_rag/state/decomposer.py" src/csa_rag/state/decomposer.py
cp "$BASE/src/csa_rag/state/state_critic.py" src/csa_rag/state/state_critic.py
cp "$BASE/src/csa_rag/retrieval/slot_router.py" src/csa_rag/retrieval/slot_router.py
cp "$BASE/src/csa_rag/utils/relation_aware_hints.py" src/csa_rag/utils/relation_aware_hints.py
cp "$BASE/src/csa_rag/utils/answer_utils.py" src/csa_rag/utils/answer_utils.py
cp "$BASE/prompts/decompose.txt" prompts/decompose.txt

cp "$BASE/scripts/run_hotpot_eval.py" scripts/run_hotpot_eval.py
cp "$BASE/scripts/run_2wiki_eval.py" scripts/run_2wiki_eval.py
cp "$BASE/scripts/run_musique_eval.py" scripts/run_musique_eval.py

# remove later experimental modules
rm -f src/csa_rag/state/semantic_slot_verifier.py
rm -f src/csa_rag/state/compositional_answer_operator.py
rm -f src/csa_rag/state/evidence_sufficiency_gate.py
rm -f src/csa_rag/retrieval/entity_expansion.py
rm -f src/csa_rag/retrieval/retrieval_executor.py

python -m py_compile \
  src/csa_rag/agent/pipeline.py \
  src/csa_rag/state/decomposer.py \
  src/csa_rag/state/state_critic.py \
  src/csa_rag/retrieval/slot_router.py \
  src/csa_rag/utils/relation_aware_hints.py \
  src/csa_rag/utils/answer_utils.py \
  scripts/run_hotpot_eval.py \
  scripts/run_2wiki_eval.py \
  scripts/run_musique_eval.py

echo "[done] patch16 backbone restored"
