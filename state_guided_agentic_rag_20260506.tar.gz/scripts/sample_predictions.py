from __future__ import annotations
import json
import random
from pathlib import Path
import typer

app = typer.Typer()

@app.command()
def main(
    predictions: Path = typer.Option(..., exists=True),
    n: int = typer.Option(10),
    seed: int = typer.Option(42),
):
    rows = []
    with predictions.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                rows.append(json.loads(line))

    random.seed(seed)
    picks = random.sample(rows, min(n, len(rows)))

    for i, row in enumerate(picks, 1):
        print("=" * 140)
        print(f"[sample {i}]")
        print("qid:", row.get("qid"))
        print("question:", row.get("question"))
        print("gold:", row.get("gold_answer"))
        print("pred:", row.get("pred_answer"))
        print("raw_pred:", row.get("raw_pred_answer"))
        print("steps:", row.get("steps"))
        print("error:", row.get("error"))
        print("state:", json.dumps(row.get("state", {}), ensure_ascii=False, indent=2))
        print("retrieved_evidence_top3:")
        for e in row.get("retrieved_evidence", [])[:3]:
            print(json.dumps(e, ensure_ascii=False))
        print("rationale:", row.get("rationale"))

if __name__ == "__main__":
    app()
