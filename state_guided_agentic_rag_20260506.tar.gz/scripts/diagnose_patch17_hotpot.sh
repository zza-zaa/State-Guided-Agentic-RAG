#!/usr/bin/env bash
set -euo pipefail

cd /mnt/raid/peiyu/csa
source /mnt/raid/peiyu/envs/csa/bin/activate

echo "==================== CHECK DIRS ===================="
mkdir -p outputs outputs/logs
ls -ld outputs outputs/logs

echo
echo "==================== SYNTAX CHECK ===================="
python -m py_compile \
  src/csa_rag/retrieval/retrieval_executor.py \
  src/csa_rag/agent/pipeline.py \
  scripts/run_hotpot_eval.py

echo
echo "==================== PIPELINE PATCH CHECK ===================="
grep -n "RetrievalExecutor\|self.retrieval_executor\|route_title_hits\|slot_router" src/csa_rag/agent/pipeline.py || true

echo
echo "==================== PIPELINE CONTEXT ===================="
sed -n '1,120p' src/csa_rag/agent/pipeline.py
echo "--------------------"
sed -n '150,280p' src/csa_rag/agent/pipeline.py

echo
echo "==================== HOTPOT SMOKE TEST (LIMIT 1) ===================="
rm -f outputs/hotpot_dev1_patch17_smoke.jsonl
rm -f outputs/logs/hotpot_dev1_patch17_smoke.log

python -u scripts/run_hotpot_eval.py \
  --dataset-path /mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json \
  --index-dir data/indexes/hotpot \
  --models-config configs/models.yaml \
  --output-path outputs/hotpot_dev1_patch17_smoke.jsonl \
  --limit 1 \
  > outputs/logs/hotpot_dev1_patch17_smoke.log 2>&1 || true

echo
echo "==================== FILE CHECK ===================="
ls -l outputs/hotpot_dev1_patch17_smoke.jsonl outputs/logs/hotpot_dev1_patch17_smoke.log 2>/dev/null || true

echo
echo "==================== SMOKE LOG ===================="
cat outputs/logs/hotpot_dev1_patch17_smoke.log || true

echo
echo "==================== SMOKE PREDICTION ===================="
cat outputs/hotpot_dev1_patch17_smoke.jsonl || true
