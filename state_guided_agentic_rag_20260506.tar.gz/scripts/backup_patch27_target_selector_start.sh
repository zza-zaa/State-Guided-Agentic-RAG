#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch27_target_selector_start
cp -r src scripts prompts configs backups/patch27_target_selector_start/
echo "[done] backup created at backups/patch27_target_selector_start"
