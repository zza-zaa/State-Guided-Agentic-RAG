from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old_import = "from csa_rag.retrieval.slot_router import SlotRouter"
new_import = "from csa_rag.retrieval.slot_router import SlotRouter\nfrom csa_rag.retrieval.typed_second_hop import TypedSecondHopQueryBuilder"
if "TypedSecondHopQueryBuilder" not in text:
    text = text.replace(old_import, new_import)

old_init = "self.slot_router = SlotRouter()"
new_init = "self.slot_router = SlotRouter()\n        self.typed_second_hop = TypedSecondHopQueryBuilder()"
if "self.typed_second_hop = TypedSecondHopQueryBuilder()" not in text:
    text = text.replace(old_init, new_init)

old_block = """        second_hop: List[Evidence] = []
        if self.enable_second_hop:
            dep_values = self._resolved_dependency_values(state, slot)
            if dep_values:
                aug_query = f"{query}. Focus on {'; '.join(dep_values)}."
                if typed_spec is not None:
                    aug_query = f"{aug_query} Typed answer target: {getattr(typed_spec, 'answer_type', 'entity')}."
                dense2 = self.retriever.search(aug_query, top_k=top_k_dense)
                reranked2 = self.reranker.rerank(query=aug_query, evidence=dense2, top_k=top_k_rerank)
                second_hop = reranked2[:step_cap]
"""

new_block = """        second_hop: List[Evidence] = []
        if self.enable_second_hop:
            dep_values = self._resolved_dependency_values(state, slot)
            if dep_values:
                aug_query = self.typed_second_hop.build(
                    question=state.question,
                    slot=slot,
                    dep_values=dep_values,
                    typed_spec=typed_spec,
                )
                dense2 = self.retriever.search(aug_query, top_k=top_k_dense)
                reranked2 = self.reranker.rerank(query=aug_query, evidence=dense2, top_k=top_k_rerank)
                second_hop = reranked2[:step_cap]
"""

if old_block not in text:
    raise SystemExit("Could not find second-hop block in pipeline.py")

text = text.replace(old_block, new_block)
p.write_text(text, encoding="utf-8")
print("[done] patched pipeline with typed second-hop builder")
