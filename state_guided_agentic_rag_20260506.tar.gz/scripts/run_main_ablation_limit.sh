#!/usr/bin/env bash
set -euo pipefail

ABLATION_NAME="$1"
DATASET_KEY="$2"
LIMIT="${3:-1500}"
OFFSET="${4:-0}"

cd /mnt/raid/peiyu/csa
set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u
export PYTHONPATH=src

CONFIG="configs/main_ablations/${ABLATION_NAME}.yaml"

if [ "$DATASET_KEY" = "hotpot" ]; then
  RUNNER="scripts/run_hotpot_eval.py"
  DATASET_PATH="/mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json"
  INDEX_DIR="data/indexes/hotpot"
elif [ "$DATASET_KEY" = "2wiki" ]; then
  RUNNER="scripts/run_2wiki_eval.py"
  DATASET_PATH="/mnt/raid/peiyu/dataset/2Wiki/dev.json"
  INDEX_DIR="data/indexes/2wiki"
elif [ "$DATASET_KEY" = "musique" ]; then
  RUNNER="scripts/run_musique_eval.py"
  DATASET_PATH="/mnt/raid/peiyu/dataset/musique/musique_ans_v1.0_dev.jsonl"
  INDEX_DIR="data/indexes/musique"
else
  echo "[error] Unknown dataset key: $DATASET_KEY"
  exit 1
fi

OUT_PREFIX="outputs/${DATASET_KEY}_${ABLATION_NAME}_${LIMIT}"
RUN_LOG="${OUT_PREFIX}.log"
TIME_LOG="${OUT_PREFIX}.time"
METRICS="${OUT_PREFIX}_metrics.json"

if [ -s "${OUT_PREFIX}.jsonl" ] && [ -s "$METRICS" ]; then
  echo "[skip] existing result found: $METRICS"
  cat "$METRICS"
  exit 0
fi

echo "[run] ablation=${ABLATION_NAME}, dataset=${DATASET_KEY}, limit=${LIMIT}, offset=${OFFSET}, gpu=${CUDA_VISIBLE_DEVICES:-NA}"

/usr/bin/time -f "wall_sec=%e\nuser_sec=%U\nsys_sec=%S\nmax_rss_kb=%M" \
  -o "$TIME_LOG" \
  python -u "$RUNNER" \
    --dataset-path "$DATASET_PATH" \
    --index-dir "$INDEX_DIR" \
    --models-config "$CONFIG" \
    --output-path "${OUT_PREFIX}.jsonl" \
    --limit "$LIMIT" \
    --offset "$OFFSET" \
  > "$RUN_LOG" 2>&1

python scripts/eval_em_f1.py \
  --predictions "${OUT_PREFIX}.jsonl" \
  --output "$METRICS"

python scripts/emnlp_error_audit_v2.py \
  --predictions "${OUT_PREFIX}.jsonl" \
  --output "${OUT_PREFIX}_audit.md"

python scripts/relation_family_breakdown_v2.py \
  --predictions "${OUT_PREFIX}.jsonl" \
  --output "${OUT_PREFIX}_family.md"

echo "[metrics]"
cat "$METRICS"

echo "[time]"
cat "$TIME_LOG"
