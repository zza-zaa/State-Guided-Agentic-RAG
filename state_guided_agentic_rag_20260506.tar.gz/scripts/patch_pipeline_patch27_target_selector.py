from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old_import = "from csa_rag.utils.typed_answer_grounder import TypedAnswerGrounder"
new_import = "from csa_rag.utils.typed_answer_grounder import TypedAnswerGrounder\nfrom csa_rag.utils.typed_target_selector import TypedTargetSelector"
if "TypedTargetSelector" not in text:
    text = text.replace(old_import, new_import)

old_init = 'self.answer_grounder = TypedAnswerGrounder()'
new_init = 'self.answer_grounder = TypedAnswerGrounder()\n        self.enable_typed_target_selector = pipe_cfg.get("enable_typed_target_selector", True)\n        self.target_selector = TypedTargetSelector(self.llm)'
if "self.target_selector = TypedTargetSelector(self.llm)" not in text:
    text = text.replace(old_init, new_init)

old_block = """        answer, rationale = self._answer(state)

        if self.enable_typed_answer_grounding:
            answer = self.answer_grounder.ground(
                question=question,
                raw_answer=answer,
                state=state,
                evidence=all_evidence,
                typed_spec=typed_spec,
            )
"""
new_block = """        answer, rationale = self._answer(state)

        if self.enable_typed_target_selector and self.target_selector.should_run(
            question=question,
            raw_answer=answer,
            state=state,
            typed_spec=typed_spec,
        ):
            answer = self.target_selector.select(
                question=question,
                raw_answer=answer,
                state=state,
                evidence=all_evidence,
                typed_spec_text=typed_spec_text,
            )

        if self.enable_typed_answer_grounding:
            answer = self.answer_grounder.ground(
                question=question,
                raw_answer=answer,
                state=state,
                evidence=all_evidence,
                typed_spec=typed_spec,
            )
"""
if old_block not in text:
    raise SystemExit("Could not find answer grounding block in pipeline.py")

text = text.replace(old_block, new_block)
p.write_text(text, encoding="utf-8")
print("[done] patched pipeline with typed target selector")
