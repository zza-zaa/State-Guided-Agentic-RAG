#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="/mnt/raid/peiyu/csa"
PACKAGE_NAME="state_guided_agentic_rag"
DATE_TAG=$(date +"%Y%m%d")
STAGE_DIR="/tmp/${PACKAGE_NAME}_${DATE_TAG}"
OUT_DIR="${PROJECT_ROOT}/release"
TARBALL="${OUT_DIR}/${PACKAGE_NAME}_${DATE_TAG}.tar.gz"

cd "$PROJECT_ROOT"

rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR"
mkdir -p "$OUT_DIR"

echo "[stage] copying source files to $STAGE_DIR"

rsync -av \
  --exclude ".git/" \
  --exclude "__pycache__/" \
  --exclude "*.pyc" \
  --exclude "*.pyo" \
  --exclude ".pytest_cache/" \
  --exclude ".mypy_cache/" \
  --exclude ".ruff_cache/" \
  --exclude ".idea/" \
  --exclude ".vscode/" \
  \
  --exclude "data/" \
  --exclude "dataset/" \
  --exclude "datasets/" \
  --exclude "raw_data/" \
  --exclude "processed_data/" \
  --exclude "indexes/" \
  --exclude "models/" \
  --exclude "checkpoints/" \
  --exclude "ckpts/" \
  --exclude "weights/" \
  \
  --exclude "outputs/" \
  --exclude "logs/" \
  --exclude "runs/" \
  --exclude "wandb/" \
  --exclude "tensorboard/" \
  --exclude "backups/" \
  --exclude "release/" \
  \
  --exclude "*.faiss" \
  --exclude "*.index" \
  --exclude "*.npy" \
  --exclude "*.npz" \
  --exclude "*.pkl" \
  --exclude "*.pickle" \
  --exclude "*.parquet" \
  --exclude "*.arrow" \
  --exclude "*.bin" \
  --exclude "*.safetensors" \
  --exclude "*.pt" \
  --exclude "*.pth" \
  --exclude "*.ckpt" \
  --exclude "*.tar.gz" \
  --exclude "*.zip" \
  --exclude "*.jsonl" \
  --exclude "*.log" \
  --exclude "requirements_full_freeze.txt" \
  ./ "$STAGE_DIR/"

echo "[check] listing large files over 20MB"
find "$STAGE_DIR" -type f -size +20M -print > "$OUT_DIR/large_files_in_package_${DATE_TAG}.txt" || true

if [ -s "$OUT_DIR/large_files_in_package_${DATE_TAG}.txt" ]; then
  echo "[warning] large files found in staging directory:"
  cat "$OUT_DIR/large_files_in_package_${DATE_TAG}.txt"
  echo "[warning] please inspect before release."
else
  echo "[ok] no files larger than 20MB found."
fi

echo "[check] searching suspicious data/model/index files"
find "$STAGE_DIR" -type f | grep -E '\.(faiss|index|npy|npz|pkl|pickle|parquet|arrow|bin|safetensors|pt|pth|ckpt|jsonl)$' \
  > "$OUT_DIR/suspicious_files_in_package_${DATE_TAG}.txt" || true

if [ -s "$OUT_DIR/suspicious_files_in_package_${DATE_TAG}.txt" ]; then
  echo "[warning] suspicious files found:"
  cat "$OUT_DIR/suspicious_files_in_package_${DATE_TAG}.txt"
  echo "[warning] please inspect before release."
else
  echo "[ok] no suspicious data/model/index files found."
fi

echo "[package] creating tarball $TARBALL"
tar -czf "$TARBALL" -C "/tmp" "$(basename "$STAGE_DIR")"

echo "[done] package created:"
ls -lh "$TARBALL"

echo "[manifest] writing package file list"
tar -tzf "$TARBALL" > "$OUT_DIR/${PACKAGE_NAME}_${DATE_TAG}_filelist.txt"

echo "[done] file list:"
echo "$OUT_DIR/${PACKAGE_NAME}_${DATE_TAG}_filelist.txt"
