from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

# 1) import
imp = "from csa_rag.state.state_critic import StateCritic"
if imp not in text:
    candidates = [
        "from csa_rag.state.tracker import KnowledgeStateTracker",
        "from csa_rag.state.decomposer import EvidenceSlotDecomposer",
    ]
    inserted = False
    for anchor in candidates:
        if anchor in text:
            text = text.replace(anchor, anchor + "\n" + imp, 1)
            inserted = True
            break
    if not inserted:
        raise SystemExit("Could not insert StateCritic import")

# 2) __init__ init line
init_line = "self.state_critic = StateCritic()"
if init_line not in text:
    candidates = [
        "self.tracker = KnowledgeStateTracker(self.llm)",
        "self.router = UncertaintyGuidedRouter()",
    ]
    inserted = False
    for anchor in candidates:
        if anchor in text:
            text = text.replace(anchor, anchor + "\n        " + init_line, 1)
            inserted = True
            break
    if not inserted:
        raise SystemExit("Could not insert self.state_critic init")

# 3) insert review call after posthoc_validate_state, or after tracker.update if needed
review_line = "state = self.state_critic.review(state, all_evidence)"
if review_line not in text:
    lines = text.splitlines()
    out = []
    inserted = False

    for i, line in enumerate(lines):
        out.append(line)

        if "posthoc_validate_state(" in line and "state =" in line and not inserted:
            indent = line[:len(line) - len(line.lstrip())]
            out.append(f"{indent}{review_line}")
            inserted = True

    # fallback: insert immediately after tracker.update if posthoc line absent
    if not inserted:
        out = []
        for i, line in enumerate(lines):
            out.append(line)
            if "self.tracker.update(" in line and "state =" in line and not inserted:
                indent = line[:len(line) - len(line.lstrip())]
                out.append(f"{indent}{review_line}")
                inserted = True

    if not inserted:
        raise SystemExit("Could not insert state critic review call")

    text = "\n".join(out) + "\n"

p.write_text(text, encoding="utf-8")
print("[ok] pipeline patched with StateCritic (v2)")
