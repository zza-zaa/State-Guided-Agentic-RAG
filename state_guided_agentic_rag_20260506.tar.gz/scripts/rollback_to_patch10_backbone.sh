#!/usr/bin/env bash
set -euo pipefail

cd /mnt/raid/peiyu/csa

echo "[1/4] backup current work"
mkdir -p backups/manual_before_patch10_backbone_restore
cp -r src prompts scripts configs backups/manual_before_patch10_backbone_restore/

echo "[2/4] restore patch10 backbone files from backups/patch11_start"
cp backups/patch11_start/src/csa_rag/agent/pipeline.py src/csa_rag/agent/pipeline.py
cp backups/patch11_start/src/csa_rag/retrieval/retriever.py src/csa_rag/retrieval/retriever.py
cp backups/patch11_start/src/csa_rag/utils/operator_gate.py src/csa_rag/utils/operator_gate.py
cp backups/patch11_start/src/csa_rag/utils/support_path.py src/csa_rag/utils/support_path.py
cp backups/patch11_start/src/csa_rag/utils/answer_utils.py src/csa_rag/utils/answer_utils.py

cp backups/patch11_start/prompts/decompose.txt prompts/decompose.txt

cp backups/patch11_start/scripts/run_hotpot_eval.py scripts/run_hotpot_eval.py
cp backups/patch11_start/scripts/run_2wiki_eval.py scripts/run_2wiki_eval.py
cp backups/patch11_start/scripts/run_musique_eval.py scripts/run_musique_eval.py

echo "[3/4] remove later answer-side experimental files if present"
rm -f src/csa_rag/utils/final_answer_resolver.py
rm -f src/csa_rag/utils/state_answer_selector.py

echo "[4/4] syntax check"
python -m py_compile \
  src/csa_rag/agent/pipeline.py \
  src/csa_rag/retrieval/retriever.py \
  src/csa_rag/utils/operator_gate.py \
  src/csa_rag/utils/support_path.py \
  src/csa_rag/utils/answer_utils.py \
  scripts/run_hotpot_eval.py \
  scripts/run_2wiki_eval.py \
  scripts/run_musique_eval.py

echo "[done] rollback to patch10 backbone completed"
