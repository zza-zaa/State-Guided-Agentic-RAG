#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch26_typed_answer_grounder_start
cp -r src scripts prompts configs backups/patch26_typed_answer_grounder_start/
echo "[done] backup created at backups/patch26_typed_answer_grounder_start"
