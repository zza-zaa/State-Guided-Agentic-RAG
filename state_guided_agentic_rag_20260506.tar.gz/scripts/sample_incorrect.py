from __future__ import annotations
import json
import random
from pathlib import Path
import typer

app = typer.Typer()

def norm(x):
    return " ".join(str(x or "").strip().lower().split())

@app.command()
def main(
    predictions: Path = typer.Option(..., exists=True),
    n: int = typer.Option(5),
    seed: int = typer.Option(42),
):
    rows = []
    with predictions.open("r", encoding="utf-8") as f:
        for line in f:
            x = json.loads(line)
            gold = norm(x.get("gold_answer"))
            pred = norm(x.get("pred_answer"))
            if gold != pred:
                rows.append(x)

    random.seed(seed)
    picks = random.sample(rows, min(n, len(rows)))

    for i, row in enumerate(picks, 1):
        print("=" * 140)
        print(f"[incorrect sample {i}]")
        print("qid:", row.get("qid"))
        print("question:", row.get("question"))
        print("gold:", row.get("gold_answer"))
        print("pred:", row.get("pred_answer"))
        print("raw_pred:", row.get("raw_pred_answer"))
        print("steps:", row.get("steps"))
        print("error:", row.get("error"))
        print("state:", json.dumps(row.get("state", {}), ensure_ascii=False, indent=2))
        print("retrieved_evidence_top5:")
        for e in row.get("retrieved_evidence", [])[:5]:
            print(json.dumps(e, ensure_ascii=False))
        print("rationale:", row.get("rationale"))

if __name__ == "__main__":
    app()
