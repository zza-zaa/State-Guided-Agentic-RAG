from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old = 'self.enable_typed_target_selector = pipe_cfg.get("enable_typed_target_selector", True)'
new = 'self.enable_typed_target_selector = pipe_cfg.get("enable_typed_target_selector", False)'

if old in text:
    text = text.replace(old, new)
    p.write_text(text, encoding="utf-8")
    print("[done] disabled target selector by default")
else:
    print("[skip] target selector default line not found")
