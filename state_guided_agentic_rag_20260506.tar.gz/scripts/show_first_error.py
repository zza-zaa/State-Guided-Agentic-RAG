from __future__ import annotations
from pathlib import Path
import typer

app = typer.Typer()

@app.command()
def main(logfile: Path = typer.Option(..., exists=True)):
    text = logfile.read_text(encoding="utf-8", errors="ignore")
    parts = text.split("=" * 120)
    for part in parts:
        part = part.strip()
        if part:
            print(part[:6000])
            return
    print("No error block found.")

if __name__ == "__main__":
    app()
