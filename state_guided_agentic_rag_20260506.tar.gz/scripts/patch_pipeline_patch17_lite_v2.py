from pathlib import Path
import re

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

pattern = re.compile(
    r'''
(?P<indent>\s*)routed_query\s*=\s*plan\.query\s+if\s+getattr\(plan,\s*"query",\s*None\)\s+else\s+query
\n(?P=indent)dense\s*=\s*self\.retriever\.search\(routed_query,\s*top_k=top_k_dense\)
\n(?P=indent)reranked\s*=\s*self\.reranker\.rerank\(query=routed_query,\s*evidence=dense,\s*top_k=top_k_rerank\)
\n(?P=indent)first_hop\s*=\s*reranked\[:step_cap\]
''',
    re.VERBOSE
)

replacement = r'''\
\g<indent>routed_query = plan.query if getattr(plan, "query", None) else query

\g<indent>route_title_hits = []
\g<indent>restrict_titles = list(getattr(plan, "restrict_titles", None) or [])
\g<indent>if restrict_titles:
\g<indent>    if hasattr(self.retriever, "fetch_by_titles_fuzzy"):
\g<indent>        route_title_hits = self.retriever.fetch_by_titles_fuzzy(restrict_titles, top_per_title=1)
\g<indent>    elif hasattr(self.retriever, "fetch_by_titles"):
\g<indent>        route_title_hits = self.retriever.fetch_by_titles(restrict_titles, top_per_title=1)

\g<indent>    if route_title_hits:
\g<indent>        route_title_hits = self.reranker.rerank(
\g<indent>            query=routed_query,
\g<indent>            evidence=route_title_hits,
\g<indent>            top_k=min(len(route_title_hits), max(2, step_cap)),
\g<indent>        )

\g<indent>dense = self.retriever.search(routed_query, top_k=top_k_dense)
\g<indent>reranked = self.reranker.rerank(query=routed_query, evidence=dense, top_k=top_k_rerank)
\g<indent>first_hop = self._merge_evidence(route_title_hits, reranked[:step_cap], limit=step_cap)
'''

new_text, n = pattern.subn(replacement, text, count=1)
if n != 1:
    raise SystemExit("Could not find routed retrieval block in pipeline.py")

p.write_text(new_text, encoding="utf-8")
print("[ok] patch17-lite v2 applied to pipeline.py")
