from pathlib import Path
import json

ablations = [
    "main_state_only_14b",
    "main_no_question_type_14b",
    "main_no_state_optimization_14b",
    "main_full_14b",
]
datasets = ["hotpot", "2wiki", "musique"]

names = {
    "main_state_only_14b": "State Only",
    "main_no_question_type_14b": "w/o Question Type Optimization",
    "main_no_state_optimization_14b": "w/o State-based Optimization",
    "main_full_14b": "Full Model",
}

lines = []
lines.append("| Variant | Dataset | EM | F1 | Avg Steps | Error Count |")
lines.append("|---|---|---:|---:|---:|---:|")

for ab in ablations:
    for ds in datasets:
        p = Path(f"outputs/{ds}_{ab}_500_metrics.json")
        if not p.exists():
            lines.append(f"| {names[ab]} | {ds} | - | - | - | - |")
            continue
        x = json.loads(p.read_text(encoding="utf-8"))
        lines.append(
            f"| {names[ab]} | {ds} | "
            f"{x.get('EM','-')} | {x.get('F1','-')} | "
            f"{x.get('avg_steps','-')} | {x.get('error_count','-')} |"
        )

out = Path("outputs/main_ablation_summary_500.md")
out.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(f"[done] wrote {out}")
