#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch24_typed_soft_start
cp -r src prompts scripts configs backups/patch24_typed_soft_start/
echo "[done] backup created at backups/patch24_typed_soft_start"
