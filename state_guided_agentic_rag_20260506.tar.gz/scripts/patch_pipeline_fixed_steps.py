from pathlib import Path
import re

p = Path("src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old = '''        state = self.decomposer.decompose(question, typed_spec_text=typed_spec_text)
        all_evidence: List[Evidence] = []
        max_steps = self.cfg["agent"].get("max_steps", 5)
        retry_used = False

        for _ in range(max_steps):
            evidence = self._retrieve_step(state, typed_spec=typed_spec)
            if evidence:
                all_evidence.extend(evidence)
                state = self.tracker.update(state, evidence)
                state = self.state_critic.review(state, all_evidence)

            if self.enable_typed_retry and not retry_used:
                retry_evidence = self._typed_retry_step(state, typed_spec=typed_spec)
                if retry_evidence:
                    all_evidence.extend(retry_evidence)
                    state = self.tracker.update(state, retry_evidence)
                    state = self.state_critic.review(state, all_evidence)
                    retry_used = True

            if self.calibrator.should_stop(state, max_steps=max_steps):
                break
'''

new = '''        state = self.decomposer.decompose(question, typed_spec_text=typed_spec_text)
        all_evidence: List[Evidence] = []

        agent_cfg = self.cfg.get("agent", {})
        pipe_cfg = self.cfg.get("pipeline", {})

        # Fixed-step experiment support:
        # - For normal runs, use agent.max_steps as before.
        # - For fixed-step sensitivity runs, pipeline.fixed_steps / step_budget
        #   overrides agent.max_steps.
        max_steps = int(
            pipe_cfg.get(
                "fixed_steps",
                pipe_cfg.get(
                    "fixed_step_limit",
                    pipe_cfg.get(
                        "fixed_max_steps",
                        pipe_cfg.get(
                            "step_budget",
                            pipe_cfg.get("max_steps", agent_cfg.get("max_steps", 5)),
                        ),
                    ),
                ),
            )
        )

        force_fixed_steps = bool(
            pipe_cfg.get("force_fixed_steps", False)
            or pipe_cfg.get("disable_early_stop", False)
        )
        enable_early_stop = bool(pipe_cfg.get("enable_early_stop", True))

        retry_used = False

        for _ in range(max_steps):
            evidence = self._retrieve_step(state, typed_spec=typed_spec)
            if evidence:
                all_evidence.extend(evidence)
                state = self.tracker.update(state, evidence)
                state = self.state_critic.review(state, all_evidence)

            if self.enable_typed_retry and not retry_used:
                retry_evidence = self._typed_retry_step(state, typed_spec=typed_spec)
                if retry_evidence:
                    all_evidence.extend(retry_evidence)
                    state = self.tracker.update(state, retry_evidence)
                    state = self.state_critic.review(state, all_evidence)
                    retry_used = True

            # In fixed-step experiments, do not stop early by confidence.
            if (not force_fixed_steps) and enable_early_stop:
                if self.calibrator.should_stop(state, max_steps=max_steps):
                    break
'''

if old not in text:
    raise SystemExit("[error] target run-loop block not found; pipeline.py may have changed")

text = text.replace(old, new, 1)
p.write_text(text, encoding="utf-8")
print("[ok] patched src/csa_rag/agent/pipeline.py for fixed-step support")
