#!/usr/bin/env bash
set -euo pipefail
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch17_lite_start
cp -r src prompts scripts configs backups/patch17_lite_start/
echo "[done] backup created at backups/patch17_lite_start"
