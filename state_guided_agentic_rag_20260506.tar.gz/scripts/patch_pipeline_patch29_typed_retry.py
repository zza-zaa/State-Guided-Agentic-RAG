from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old_import = "from csa_rag.retrieval.typed_second_hop import TypedSecondHopQueryBuilder"
new_import = "from csa_rag.retrieval.typed_second_hop import TypedSecondHopQueryBuilder\nfrom csa_rag.retrieval.typed_retry_builder import TypedRetryQueryBuilder"
if "TypedRetryQueryBuilder" not in text:
    text = text.replace(old_import, new_import)

old_init = "self.typed_second_hop = TypedSecondHopQueryBuilder()"
new_init = "self.typed_second_hop = TypedSecondHopQueryBuilder()\n        self.typed_retry_builder = TypedRetryQueryBuilder()\n        self.enable_typed_retry = pipe_cfg.get(\"enable_typed_retry\", True)"
if "self.typed_retry_builder = TypedRetryQueryBuilder()" not in text:
    text = text.replace(old_init, new_init)

anchor = "    def _answer_once(self, state: KnowledgeState) -> tuple[str, str]:"
insert_block = """
    def _priority_open_slots(self, state: KnowledgeState):
        role_rank = {"bridge": 0, "answer_target": 1, "other": 2}
        slots = []
        for s in state.slots:
            if getattr(s, "status", "") in {"missing", "conflict", "candidate"}:
                role = getattr(s, "target_role", "other")
                slots.append((role_rank.get(role, 9), getattr(s, "slot_id", ""), s))
        slots.sort(key=lambda x: (x[0], x[1]))
        return [x[2] for x in slots]

    def _typed_retry_step(self, state: KnowledgeState, typed_spec=None) -> list[Evidence]:
        open_slots = self._priority_open_slots(state)
        if not open_slots:
            return []

        slot = open_slots[0]
        confirmed_vals = self._confirmed_bridge_values(state) + self._resolved_dependency_values(state, slot)

        if not confirmed_vals:
            confirmed_vals = []
            for s in state.slots:
                if getattr(s, "status", "") == "confirmed" and getattr(s, "value", None):
                    confirmed_vals.append(str(getattr(s, "value")))

        query = self.typed_retry_builder.build(
            question=state.question,
            slot=slot,
            confirmed_values=confirmed_vals,
            typed_spec=typed_spec,
        )

        top_k_dense = max(18, self.cfg["agent"].get("max_evidence_per_step", 5) * 4)
        top_k_rerank = max(8, self.cfg["agent"].get("max_evidence_per_step", 5) * 2)

        dense = self.retriever.search(query, top_k=top_k_dense)
        reranked = self.reranker.rerank(query=query, evidence=dense, top_k=top_k_rerank)
        return reranked[: self.cfg["agent"].get("max_evidence_per_step", 5)]

"""
if insert_block not in text and anchor in text:
    text = text.replace(anchor, insert_block + anchor)

old_run_line = "        max_steps = self.cfg[\"agent\"].get(\"max_steps\", 5)"
new_run_line = "        max_steps = self.cfg[\"agent\"].get(\"max_steps\", 5)\n        retry_used = False"
if "retry_used = False" not in text:
    text = text.replace(old_run_line, new_run_line)

old_block = """            if self.calibrator.should_stop(state, max_steps=max_steps):
                break
"""
new_block = """            if self.enable_typed_retry and not retry_used:
                retry_evidence = self._typed_retry_step(state, typed_spec=typed_spec)
                if retry_evidence:
                    all_evidence.extend(retry_evidence)
                    state = self.tracker.update(state, retry_evidence)
                    state = self.state_critic.review(state, all_evidence)
                    retry_used = True

            if self.calibrator.should_stop(state, max_steps=max_steps):
                break
"""
if old_block in text and "retry_evidence = self._typed_retry_step" not in text:
    text = text.replace(old_block, new_block)

p.write_text(text, encoding="utf-8")
print("[done] patched pipeline with typed uncertainty retry")
