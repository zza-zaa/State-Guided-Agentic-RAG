from pathlib import Path
import re

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

# import
imp = "from csa_rag.retrieval.entity_expansion import EntityExpansionPlanner"
if imp not in text:
    anchor = "from csa_rag.retrieval.slot_router import SlotRouter"
    if anchor not in text:
        raise SystemExit("Import anchor not found")
    text = text.replace(anchor, anchor + "\n" + imp, 1)

# init
init_line = "self.entity_expander = EntityExpansionPlanner()"
if init_line not in text:
    anchor = "self.slot_router = SlotRouter()"
    if anchor not in text:
        raise SystemExit("Init anchor not found")
    text = text.replace(anchor, anchor + "\n        " + init_line, 1)

pattern = re.compile(
    r'''
(?P<indent>\s*)routed_query\s*=\s*plan\.query\s+if\s+getattr\(plan,\s*"query",\s*None\)\s+else\s+query
\n(?P=indent)dense\s*=\s*self\.retriever\.search\(routed_query,\s*top_k=top_k_dense\)
\n(?P=indent)reranked\s*=\s*self\.reranker\.rerank\(query=routed_query,\s*evidence=dense,\s*top_k=top_k_rerank\)
\n(?P=indent)first_hop\s*=\s*reranked\[:step_cap\]
''',
    re.VERBOSE
)

replacement = r'''\
\g<indent>routed_query = plan.query if getattr(plan, "query", None) else query

\g<indent>expansion_hits = []
\g<indent>parent_titles = self.entity_expander.parent_titles(state, slot)
\g<indent>if parent_titles:
\g<indent>    if hasattr(self.retriever, "fetch_by_titles_fuzzy"):
\g<indent>        expansion_hits.extend(self.retriever.fetch_by_titles_fuzzy(parent_titles, top_per_title=1))
\g<indent>    elif hasattr(self.retriever, "fetch_by_titles"):
\g<indent>        expansion_hits.extend(self.retriever.fetch_by_titles(parent_titles, top_per_title=1))

\g<indent>for q2 in self.entity_expander.build_queries(state, slot):
\g<indent>    expansion_hits.extend(self.retriever.search(q2, top_k=min(10, top_k_dense)))

\g<indent>dense = self.retriever.search(routed_query, top_k=top_k_dense)
\g<indent>reranked = self.reranker.rerank(query=routed_query, evidence=dense, top_k=top_k_rerank)

\g<indent>if expansion_hits:
\g<indent>    expansion_hits = self.reranker.rerank(
\g<indent>        query=routed_query,
\g<indent>        evidence=expansion_hits,
\g<indent>        top_k=max(4, step_cap),
\g<indent>    )

\g<indent>first_hop = self._merge_evidence(expansion_hits, reranked[:step_cap], limit=step_cap)
'''

new_text, n = pattern.subn(replacement, text, count=1)
if n != 1:
    raise SystemExit("Could not find retrieval block in pipeline.py")

p.write_text(new_text, encoding="utf-8")
print("[ok] pipeline patched with EntityExpansionPlanner")
