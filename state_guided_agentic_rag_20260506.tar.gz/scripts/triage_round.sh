#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 2 ]; then
  echo "Usage: bash scripts/triage_round.sh <old_tag> <new_tag>"
  echo "Example: bash scripts/triage_round.sh mainline_check patch8_operator_gate"
  exit 1
fi

OLD_TAG="$1"
NEW_TAG="$2"

echo "================ HOTPOT METRICS ================"
cat "outputs/hotpot_dev30_${NEW_TAG}_metrics.json" || true
echo
echo "================ 2WIKI METRICS ================"
cat "outputs/2wiki_dev30_${NEW_TAG}_metrics.json" || true
echo
echo "================ MUSIQUE METRICS ================"
cat "outputs/musique_dev100_${NEW_TAG}_metrics.json" || true
echo

echo "================ HOTPOT COMPARE ================"
python scripts/compare_two_runs.py \
  --old-predictions "outputs/hotpot_dev30_${OLD_TAG}.jsonl" \
  --new-predictions "outputs/hotpot_dev30_${NEW_TAG}.jsonl" \
  --limit 10 || true
echo

echo "================ 2WIKI COMPARE ================"
python scripts/compare_two_runs.py \
  --old-predictions "outputs/2wiki_dev30_${OLD_TAG}.jsonl" \
  --new-predictions "outputs/2wiki_dev30_${NEW_TAG}.jsonl" \
  --limit 10 || true
echo

echo "================ MUSIQUE INCORRECT SAMPLES ================"
python scripts/sample_incorrect.py \
  --predictions "outputs/musique_dev100_${NEW_TAG}.jsonl" \
  --n 5 || true
echo

echo "================ HOTPOT INCORRECT SAMPLES ================"
python scripts/sample_incorrect.py \
  --predictions "outputs/hotpot_dev30_${NEW_TAG}.jsonl" \
  --n 5 || true
echo

echo "================ 2WIKI INCORRECT SAMPLES ================"
python scripts/sample_incorrect.py \
  --predictions "outputs/2wiki_dev30_${NEW_TAG}.jsonl" \
  --n 5 || true
echo
