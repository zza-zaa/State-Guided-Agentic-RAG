#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/question_typing_v2_start
cp -r src scripts outputs backups/question_typing_v2_start/
echo "[done] backup created at backups/question_typing_v2_start"
