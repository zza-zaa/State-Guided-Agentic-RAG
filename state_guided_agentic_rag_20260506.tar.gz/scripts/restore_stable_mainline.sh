#!/usr/bin/env bash
set -euo pipefail

ROOT=/mnt/raid/peiyu/csa
cd "$ROOT"

cp backups/emnlp_upgrade_start/prompts/decompose.txt prompts/decompose.txt
cp backups/emnlp_upgrade_start/prompts/answer.txt prompts/answer.txt
cp backups/emnlp_upgrade_start/prompts/rewrite_answer.txt prompts/rewrite_answer.txt

cp backups/emnlp_upgrade_start/src/csa_rag/schema.py src/csa_rag/schema.py
cp backups/emnlp_upgrade_start/src/csa_rag/agent/calibration.py src/csa_rag/agent/calibration.py
cp backups/emnlp_upgrade_start/src/csa_rag/agent/pipeline.py src/csa_rag/agent/pipeline.py
cp backups/emnlp_upgrade_start/src/csa_rag/retrieval/retriever.py src/csa_rag/retrieval/retriever.py
cp backups/emnlp_upgrade_start/src/csa_rag/utils/answer_utils.py src/csa_rag/utils/answer_utils.py

# 如果稳定主线里没有这个文件，就删掉，避免混用
rm -f src/csa_rag/utils/question_constraints.py || true

python -m py_compile \
  src/csa_rag/schema.py \
  src/csa_rag/agent/calibration.py \
  src/csa_rag/agent/pipeline.py \
  src/csa_rag/retrieval/retriever.py \
  src/csa_rag/utils/answer_utils.py

echo "[ok] restored stable mainline"
