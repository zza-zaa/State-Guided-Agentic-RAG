#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa

cp backups/patch20_compositional_operator_start/src/csa_rag/agent/pipeline.py src/csa_rag/agent/pipeline.py

rm -f src/csa_rag/state/compositional_answer_operator.py
rm -f src/csa_rag/state/evidence_sufficiency_gate.py
rm -f src/csa_rag/state/semantic_slot_verifier.py
rm -f src/csa_rag/retrieval/entity_expansion.py

python -m py_compile \
  src/csa_rag/agent/pipeline.py \
  src/csa_rag/state/state_critic.py \
  src/csa_rag/retrieval/slot_router.py \
  scripts/run_hotpot_eval.py \
  scripts/run_2wiki_eval.py \
  scripts/run_musique_eval.py

echo "[done] restored patch16 backbone"
