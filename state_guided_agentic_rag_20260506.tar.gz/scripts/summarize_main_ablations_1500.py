from pathlib import Path
import json

ablations = [
    "main_state_only_14b",
    "main_no_question_type_14b",
    "main_no_state_optimization_14b",
]

datasets = ["hotpot", "2wiki", "musique"]

names = {
    "main_state_only_14b": "State Only",
    "main_no_question_type_14b": "w/o Question Type Optimization",
    "main_no_state_optimization_14b": "w/o State-based Optimization",
}

def read_time(path: Path):
    if not path.exists():
        return {}
    out = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            try:
                out[k] = float(v)
            except Exception:
                out[k] = v
    return out

lines = []
lines.append("| Variant | Dataset | EM | F1 | Avg Steps | Error Count | Wall Sec | Max RSS KB |")
lines.append("|---|---|---:|---:|---:|---:|---:|---:|")

records = []

for ab in ablations:
    for ds in datasets:
        p = Path(f"outputs/{ds}_{ab}_1500_metrics.json")
        tp = Path(f"outputs/{ds}_{ab}_1500.time")

        if not p.exists():
            lines.append(f"| {names[ab]} | {ds} | - | - | - | - | - | - |")
            continue

        x = json.loads(p.read_text(encoding="utf-8"))
        t = read_time(tp)

        rec = {
            "variant": names[ab],
            "dataset": ds,
            "EM": x.get("EM"),
            "F1": x.get("F1"),
            "avg_steps": x.get("avg_steps"),
            "error_count": x.get("error_count"),
            "wall_sec": t.get("wall_sec"),
            "max_rss_kb": t.get("max_rss_kb"),
        }
        records.append(rec)

        lines.append(
            f"| {rec['variant']} | {ds} | "
            f"{rec['EM']} | {rec['F1']} | {rec['avg_steps']} | {rec['error_count']} | "
            f"{rec['wall_sec']} | {rec['max_rss_kb']} |"
        )

lines.append("")
lines.append("## Average over three datasets")
lines.append("")
lines.append("| Variant | Avg EM | Avg F1 | Avg Steps | Total Errors | Avg Wall Sec |")
lines.append("|---|---:|---:|---:|---:|---:|")

for ab in ablations:
    name = names[ab]
    rs = [r for r in records if r["variant"] == name]

    if not rs:
        lines.append(f"| {name} | - | - | - | - | - |")
        continue

    def avg(key):
        vals = [r[key] for r in rs if isinstance(r.get(key), (int, float))]
        return round(sum(vals) / len(vals), 4) if vals else None

    total_err = sum(r.get("error_count", 0) or 0 for r in rs)

    lines.append(
        f"| {name} | {avg('EM')} | {avg('F1')} | {avg('avg_steps')} | "
        f"{total_err} | {avg('wall_sec')} |"
    )

out_md = Path("outputs/main_ablation_summary_1500_no_full_no_naive.md")
out_json = Path("outputs/main_ablation_summary_1500_no_full_no_naive.json")

out_md.write_text("\n".join(lines) + "\n", encoding="utf-8")
out_json.write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print(f"[done] wrote {out_md}")
print(f"[done] wrote {out_json}")
print()
print(out_md.read_text(encoding="utf-8"))
