#!/usr/bin/env bash
set -euo pipefail

cd /mnt/raid/peiyu/csa

set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u

export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export TOKENIZERS_PARALLELISM=false

mkdir -p logs outputs

datasets=("hotpot" "2wiki" "musique")

echo "========== Step 1: Materialize Only State from w/o Question Type =========="

for ds in "${datasets[@]}"; do
  src_metric="outputs/${ds}_main_no_question_type_14b_500_metrics.json"
  dst_metric="outputs/${ds}_main_only_state_14b_500_metrics.json"

  if [ -s "$dst_metric" ]; then
    echo "[skip] ${dst_metric} already exists"
    continue
  fi

  if [ -s "$src_metric" ]; then
    echo "[copy] ${src_metric} -> ${dst_metric}"
    cp "$src_metric" "$dst_metric"

    # 同步复制可能存在的预测文件、jsonl、结果文件，方便后续误差分析
    for f in outputs/${ds}_main_no_question_type_14b_500*; do
      [ -e "$f" ] || continue
      new_f="${f/main_no_question_type_14b/main_only_state_14b}"
      if [ ! -e "$new_f" ]; then
        cp "$f" "$new_f"
        echo "[copy] $f -> $new_f"
      fi
    done
  else
    echo "[warn] missing source only-state equivalent file: ${src_metric}"
    echo "[warn] if you really need a separate run, use variant=main_only_state_14b manually."
  fi
done


echo
echo "========== Step 2: Run missing Full Model =========="

run_full_one () {
  local ds="$1"
  local metric_file="outputs/${ds}_main_full_14b_500_metrics.json"
  local log_file="logs/${ds}_main_full_14b_500.log"

  if [ -s "$metric_file" ]; then
    echo "[skip] ${metric_file} already exists"
    return 0
  fi

  echo "[run] dataset=${ds}, variant=main_full_14b"
  echo "[log] ${log_file}"

  CUDA_VISIBLE_DEVICES=0 python run_main.py \
    --dataset "$ds" \
    --variant main_full_14b \
    --model_path /mnt/raid/zsb/llm_models/Qwen3-14B \
    --embedding_model /mnt/raid/peiyu/models/bge-m3 \
    --reranker_model /mnt/raid/peiyu/models/bge-reranker-v2-m3 \
    --limit 500 \
    --output_prefix "outputs/${ds}_main_full_14b_500" \
    > "$log_file" 2>&1
}

for ds in "${datasets[@]}"; do
  run_full_one "$ds"
done

echo
echo "[done] missing full model completed, only-state files materialized"
