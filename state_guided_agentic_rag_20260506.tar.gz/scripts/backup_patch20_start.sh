#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch20_compositional_operator_start
cp -r src prompts scripts configs backups/patch20_compositional_operator_start/
echo "[done] backup created at backups/patch20_compositional_operator_start"
