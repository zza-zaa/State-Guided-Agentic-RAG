from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old_block = """        merged = self._merge_evidence(first_hop, value_title_hits, second_hop, title_hits, limit=self.retrieval_merge_limit)
        return self.evidence_path_scorer.select(
            merged,
            state=state,
            slot=slot,
            typed_spec=typed_spec,
            limit=self.retrieval_merge_limit,
        )
"""
new_block = """        merged = self._merge_evidence(first_hop, value_title_hits, second_hop, title_hits, limit=self.retrieval_merge_limit)
        return merged
"""

if old_block in text:
    text = text.replace(old_block, new_block)
    p.write_text(text, encoding="utf-8")
    print("[done] disabled patch28 path scorer")
else:
    print("[skip] path scorer block not found")
