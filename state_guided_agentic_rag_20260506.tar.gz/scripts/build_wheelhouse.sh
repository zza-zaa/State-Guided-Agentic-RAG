#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

mkdir -p wheelhouse
python -m pip install --upgrade pip
pip download -r requirements.txt -d wheelhouse

echo "[done] wheelhouse saved to $ROOT_DIR/wheelhouse"
