from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

# import
imp = "from csa_rag.state.semantic_slot_verifier import SemanticSlotVerifier"
if imp not in text:
    anchor = "from csa_rag.state.state_critic import StateCritic"
    if anchor not in text:
        raise SystemExit("Import anchor not found")
    text = text.replace(anchor, anchor + "\n" + imp, 1)

# init
init_line = "self.semantic_slot_verifier = SemanticSlotVerifier()"
if init_line not in text:
    anchor = "self.state_critic = StateCritic()"
    if anchor not in text:
        raise SystemExit("Init anchor not found")
    text = text.replace(anchor, anchor + "\n        " + init_line, 1)

# call
old = "state = self.state_critic.review(state, all_evidence)"
new = "state = self.state_critic.review(state, all_evidence)\n                state = self.semantic_slot_verifier.review(state, all_evidence)"
if old not in text:
    raise SystemExit("Review anchor not found")
text = text.replace(old, new, 1)

p.write_text(text, encoding="utf-8")
print("[ok] pipeline patched with SemanticSlotVerifier")
