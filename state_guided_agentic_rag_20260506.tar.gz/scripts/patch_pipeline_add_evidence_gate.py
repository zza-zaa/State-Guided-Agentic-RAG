from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

imp = "from csa_rag.state.evidence_sufficiency_gate import EvidenceSufficiencyGate"
if imp not in text:
    anchor = "from csa_rag.state.compositional_answer_operator import CompositionalAnswerOperator"
    if anchor not in text:
        raise SystemExit("Import anchor not found")
    text = text.replace(anchor, anchor + "\n" + imp, 1)

init_line = "self.evidence_sufficiency_gate = Evidence SufficiencyGate()"
# fix if someone reruns after typo
text = text.replace("Evidence SufficiencyGate()", "EvidenceSufficiencyGate()")

good_init = "self.evidence_sufficiency_gate = EvidenceSufficiencyGate()"
if good_init not in text:
    anchor = "self.compositional_answer_operator = CompositionalAnswerOperator()"
    if anchor not in text:
        raise SystemExit("Init anchor not found")
    text = text.replace(anchor, anchor + "\n        " + good_init, 1)

old = "state = self.state_critic.review(state, all_evidence)\n                state = self.compositional_answer_operator.review(state, all_evidence)"
new = """state = self.state_critic.review(state, all_evidence)
                if self.evidence_sufficiency_gate.allow(state, all_evidence):
                    state = self.compositional_answer_operator.review(state, all_evidence)"""

if old not in text:
    raise SystemExit("Review block anchor not found")
text = text.replace(old, new, 1)

p.write_text(text, encoding="utf-8")
print("[ok] pipeline patched with EvidenceSufficiencyGate")
