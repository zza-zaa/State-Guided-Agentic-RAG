#!/usr/bin/env bash
set -euo pipefail

DATASET_KEY="$1"
LIMIT="${2:-1500}"

cd /mnt/raid/peiyu/csa
set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u
export PYTHONPATH=src

echo "============================================================"
echo "[start dataset] ${DATASET_KEY}, limit=${LIMIT}, gpu=${CUDA_VISIBLE_DEVICES:-NA}"
echo "============================================================"

# 不跑 full，不跑 naive
bash scripts/run_main_ablation_limit.sh main_state_only_14b "$DATASET_KEY" "$LIMIT" 0
bash scripts/run_main_ablation_limit.sh main_no_question_type_14b "$DATASET_KEY" "$LIMIT" 0
bash scripts/run_main_ablation_limit.sh main_no_state_optimization_14b "$DATASET_KEY" "$LIMIT" 0

echo "============================================================"
echo "[done dataset] ${DATASET_KEY}, limit=${LIMIT}, gpu=${CUDA_VISIBLE_DEVICES:-NA}"
echo "============================================================"
