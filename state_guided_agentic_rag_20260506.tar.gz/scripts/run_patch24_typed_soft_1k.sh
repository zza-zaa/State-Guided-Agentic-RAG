#!/usr/bin/env bash
set -e

cd /mnt/raid/peiyu/csa
set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u
export PYTHONPATH=src

mkdir -p outputs outputs/logs

run_dataset () {
  local name="$1"
  local runner="$2"
  local dataset_path="$3"
  local index_dir="$4"

  echo "==================== ${name} : 5x200 ===================="

  for idx in 0 1 2 3 4; do
    offset=$((idx * 200))
    out="outputs/${name}_dev200_part${idx}_patch24_typed_soft.jsonl"
    log="outputs/logs/${name}_dev200_part${idx}_patch24_typed_soft.log"

    echo "[run] ${name} chunk ${idx} offset=${offset}"

    python -u "${runner}" \
      --dataset-path "${dataset_path}" \
      --index-dir "${index_dir}" \
      --models-config configs/models.yaml \
      --output-path "${out}" \
      --limit 200 \
      --offset "${offset}" \
      > "${log}" 2>&1

    python scripts/eval_em_f1.py \
      --predictions "${out}" \
      --output "outputs/${name}_dev200_part${idx}_patch24_typed_soft_metrics.json"

    cat "outputs/${name}_dev200_part${idx}_patch24_typed_soft_metrics.json"
  done

  merged="outputs/${name}_dev1000_patch24_typed_soft.jsonl"
  : > "${merged}"
  for idx in 0 1 2 3 4; do
    cat "outputs/${name}_dev200_part${idx}_patch24_typed_soft.jsonl" >> "${merged}"
  done

  python scripts/eval_em_f1.py \
    --predictions "${merged}" \
    --output "outputs/${name}_dev1000_patch24_typed_soft_metrics.json"

  python scripts/emnlp_error_audit_v2.py \
    --predictions "${merged}" \
    --output "outputs/audit_${name}_patch24_typed_soft_1k.md"

  python scripts/relation_family_breakdown_v2.py \
    --predictions "${merged}" \
    --output "outputs/family_${name}_patch24_typed_soft_1k.md"

  echo "==================== ${name} : 1k metrics ===================="
  cat "outputs/${name}_dev1000_patch24_typed_soft_metrics.json"

  echo "==================== ${name} : 1k audit ===================="
  cat "outputs/audit_${name}_patch24_typed_soft_1k.md"

  echo "==================== ${name} : 1k family ===================="
  cat "outputs/family_${name}_patch24_typed_soft_1k.md"
}

run_dataset \
  "hotpot" \
  "scripts/run_hotpot_eval.py" \
  "/mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json" \
  "data/indexes/hotpot"

run_dataset \
  "2wiki" \
  "scripts/run_2wiki_eval.py" \
  "/mnt/raid/peiyu/dataset/2Wiki/dev.json" \
  "data/indexes/2wiki"

run_dataset \
  "musique" \
  "scripts/run_musique_eval.py" \
  "/mnt/raid/peiyu/dataset/musique/musique_ans_v1.0_dev.jsonl" \
  "data/indexes/musique"

echo "[done] patch24 typed soft 1k run finished"
