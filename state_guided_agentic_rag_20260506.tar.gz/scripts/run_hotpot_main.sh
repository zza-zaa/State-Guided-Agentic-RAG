#!/usr/bin/env bash
set -euo pipefail

source /mnt/raid/peiyu/envs/csa/bin/activate
cd /mnt/raid/peiyu/csa

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-2}"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
export HF_DATASETS_OFFLINE=1
export VLLM_ENABLE_V1_MULTIPROCESSING=0

LIMIT="${1:-100}"
OFFSET="${2:-0}"
OUT_PREFIX="outputs/hotpot_dev${LIMIT}_main"

mkdir -p outputs/logs

python -u scripts/run_hotpot_eval.py \
  --dataset-path /mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json \
  --index-dir data/indexes/hotpot \
  --models-config configs/models.yaml \
  --output-path "${OUT_PREFIX}_predictions.jsonl" \
  --limit "${LIMIT}" \
  --offset "${OFFSET}" \
  > "outputs/logs/hotpot_dev${LIMIT}_main.log" 2>&1

python scripts/eval_em_f1.py \
  --predictions "${OUT_PREFIX}_predictions.jsonl" \
  --output "${OUT_PREFIX}_metrics.json"

cat "${OUT_PREFIX}_metrics.json"
