from pathlib import Path
import yaml
import copy

base_path = Path("configs/models.yaml")
base = yaml.safe_load(base_path.read_text(encoding="utf-8"))

def ensure_pipeline(cfg):
    if "pipeline" not in cfg or cfg["pipeline"] is None:
        cfg["pipeline"] = {}
    return cfg["pipeline"]

cfg = copy.deepcopy(base)
p = ensure_pipeline(cfg)

# State Only:
# keep the stateful CSA pipeline itself,
# but disable question typing and all state-based optimization modules.
p["enable_typed_question_spec"] = False
p["enable_second_hop"] = False
p["enable_dependency_query"] = False
p["enable_title_hop"] = False
p["enable_typed_retry"] = False
p["enable_typed_answer_grounding"] = False
p["enable_typed_target_selector"] = False

out = Path("configs/main_ablations/main_state_only_14b.yaml")
out.write_text(
    yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True),
    encoding="utf-8",
)

print(f"[done] wrote {out}")
