#!/usr/bin/env bash
set -e
cd /mnt/raid/peiyu/csa
mkdir -p backups/patch22_answer_projector_start
cp -r src prompts scripts configs backups/patch22_answer_projector_start/
echo "[done] backup created at backups/patch22_answer_projector_start"
