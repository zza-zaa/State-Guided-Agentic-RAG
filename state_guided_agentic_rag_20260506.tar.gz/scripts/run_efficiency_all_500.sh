#!/usr/bin/env bash
set -euo pipefail

cd /mnt/raid/peiyu/csa
set +u
source /mnt/raid/peiyu/envs/csa/bin/activate
set -u
export PYTHONPATH=src

MODEL_CONFIG="configs/main_ablations/main_full_14b.yaml"
LIMIT=500
OFFSET=0

mkdir -p outputs/efficiency outputs/logs

run_one () {
  local DATASET_NAME="$1"
  local DATASET_PATH="$2"
  local INDEX_DIR="$3"
  local SUMMARY="outputs/efficiency/${DATASET_NAME}_ours_14b_500_summary.json"
  local DETAILS="outputs/efficiency/${DATASET_NAME}_ours_14b_500_details.jsonl"
  local LOG="outputs/logs/efficiency_${DATASET_NAME}_ours_14b_500.log"

  echo
  echo "==================== ${DATASET_NAME} Efficiency ===================="

  if [ -s "$SUMMARY" ] && [ -s "$DETAILS" ]; then
    echo "[skip] existing efficiency result found: $SUMMARY"
    cat "$SUMMARY"
    return 0
  fi

  python scripts/profile_efficiency_500.py \
    --dataset-name "$DATASET_NAME" \
    --dataset-path "$DATASET_PATH" \
    --index-dir "$INDEX_DIR" \
    --models-config "$MODEL_CONFIG" \
    --limit "$LIMIT" \
    --offset "$OFFSET" \
    --output-summary "$SUMMARY" \
    --output-details "$DETAILS" \
    > "$LOG" 2>&1

  cat "$SUMMARY"
}

run_one "hotpot" \
  "/mnt/raid/peiyu/dataset/hotpot/hotpot_dev_distractor_v1.json" \
  "data/indexes/hotpot"

run_one "2wiki" \
  "/mnt/raid/peiyu/dataset/2Wiki/dev.json" \
  "data/indexes/2wiki"

run_one "musique" \
  "/mnt/raid/peiyu/dataset/musique/musique_ans_v1.0_dev.jsonl" \
  "data/indexes/musique"

echo
echo "==================== Build Efficiency Summary Table ===================="

cat > scripts/summarize_efficiency_table.py <<'PY'
from pathlib import Path
import json

items = [
    ("hotpot", "outputs/efficiency/hotpot_ours_14b_500_summary.json"),
    ("2wiki", "outputs/efficiency/2wiki_ours_14b_500_summary.json"),
    ("musique", "outputs/efficiency/musique_ours_14b_500_summary.json"),
]

def fmt(v, nd=2):
    if v is None:
        return "-"
    if isinstance(v, (int, float)):
        return f"{v:.{nd}f}"
    return str(v)

lines = []
lines.append("| Dataset | Success | Fail | Init Sec. | Avg Time/Q excl. init | Avg Time/Q incl. amortized init | P50 | P90 | Avg Steps | Avg Input Tok. | Avg Output Tok. | Avg Total Tok. |")
lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")

for ds, path in items:
    p = Path(path)
    if not p.exists():
        lines.append(f"| {ds} | - | - | - | - | - | - | - | - | - | - | - |")
        continue

    x = json.loads(p.read_text(encoding="utf-8"))

    init_sec = x.get("init_sec_excluded")
    success = x.get("success_count") or 0
    fail = x.get("fail_count") or 0
    avg_excl = x.get("avg_time_sec_per_question_success_only_excl_init")

    if init_sec is not None and avg_excl is not None and success:
        avg_incl_amortized = avg_excl + init_sec / success
    else:
        avg_incl_amortized = None

    lines.append(
        f"| {ds} | {success} | {fail} | "
        f"{fmt(init_sec)} | "
        f"{fmt(avg_excl)} | "
        f"{fmt(avg_incl_amortized)} | "
        f"{fmt(x.get('p50_time_sec_excl_init'))} | "
        f"{fmt(x.get('p90_time_sec_excl_init'))} | "
        f"{fmt(x.get('avg_steps_success_only'))} | "
        f"{fmt(x.get('avg_estimated_input_tokens'))} | "
        f"{fmt(x.get('avg_estimated_output_tokens'))} | "
        f"{fmt(x.get('avg_estimated_total_tokens'))} |"
    )

out = Path("outputs/efficiency/efficiency_summary_ours_14b_500.md")
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(out.read_text(encoding="utf-8"))
PY

python scripts/summarize_efficiency_table.py

echo
echo "==================== Done ===================="
echo "Summary path: /mnt/raid/peiyu/csa/outputs/efficiency/efficiency_summary_ours_14b_500.md"
