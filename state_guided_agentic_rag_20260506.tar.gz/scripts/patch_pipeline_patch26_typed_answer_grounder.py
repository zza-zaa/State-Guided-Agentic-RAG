from pathlib import Path

p = Path("/mnt/raid/peiyu/csa/src/csa_rag/agent/pipeline.py")
text = p.read_text(encoding="utf-8")

old_import = "from csa_rag.utils.answer_utils import needs_answer_retry"
new_import = "from csa_rag.utils.answer_utils import needs_answer_retry\nfrom csa_rag.utils.typed_answer_grounder import TypedAnswerGrounder"
if "TypedAnswerGrounder" not in text:
    text = text.replace(old_import, new_import)

old_init = "self.enable_typed_question_spec = pipe_cfg.get(\"enable_typed_question_spec\", True)"
new_init = "self.enable_typed_question_spec = pipe_cfg.get(\"enable_typed_question_spec\", True)\n        self.enable_typed_answer_grounding = pipe_cfg.get(\"enable_typed_answer_grounding\", True)\n        self.answer_grounder = TypedAnswerGrounder()"
if "self.answer_grounder = TypedAnswerGrounder()" not in text:
    text = text.replace(old_init, new_init)

old_block = """        answer, rationale = self._answer(state)
        return RunResult(
            question=question,
            final_answer=answer,
            rationale=rationale,
            steps=state.step,
            state=state,
            retrieved_evidence=all_evidence,
        )
"""
new_block = """        answer, rationale = self._answer(state)

        if self.enable_typed_answer_grounding:
            answer = self.answer_grounder.ground(
                question=question,
                raw_answer=answer,
                state=state,
                evidence=all_evidence,
                typed_spec=typed_spec,
            )

        return RunResult(
            question=question,
            final_answer=answer,
            rationale=rationale,
            steps=state.step,
            state=state,
            retrieved_evidence=all_evidence,
        )
"""

if old_block not in text:
    raise SystemExit("Could not find final answer block in pipeline.py")

text = text.replace(old_block, new_block)
p.write_text(text, encoding="utf-8")
print("[done] patched pipeline with typed answer grounder")
